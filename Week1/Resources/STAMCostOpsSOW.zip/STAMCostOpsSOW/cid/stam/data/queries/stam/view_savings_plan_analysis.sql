CREATE OR REPLACE VIEW "view_savings_plan_analysis" AS 
SELECT DISTINCT
  "date_trunc"('hour', "line_item_usage_start_date") start_date
, "date_trunc"('hour', "line_item_usage_end_date") end_date
, "line_item_resource_id" resource_id
, "year"
, "month"
, "product_gpu"
, "savings_plan_savings_plan_rate" sp_rate
, "savings_plan_used_commitment" sp_used_commitment
, substr("savings_plan_savings_plan_a_r_n", strpos("savings_plan_savings_plan_a_r_n",'/')+1) sp_arn
, substr("savings_plan_start_time", 1,10) sp_start_time
, substr("savings_plan_end_time", 1,10) sp_end_time
--, (CASE WHEN "savings_plan_start_time" <> '' THEN substr("savings_plan_start_time", 1,10) ELSE '' END) sp_start_time
--, (CASE WHEN "savings_plan_end_time" <> '' THEN substr("savings_plan_end_time", 1,10) ELSE '' END) sp_end_time
, "line_item_line_item_type" charge_type
, "bill_payer_account_id" payer
, "line_item_usage_account_id" linked_acct_id
, "line_item_product_code" product_code
, "product_instance_family" instance_family
, "product_instance_type" instance_type
, "product_tenancy" tenancy
, "product_volume_type" storage_class
, "product_location" region
, "product_location_type" location_type
, "product_operating_system" operating_system
, "product_vcpu"
, "line_item_operation" operation
, "line_item_line_item_description" description
, "line_item_unblended_rate" OnDemand_rate
, "pricing_term" pricing_term
, "line_item_usage_type" usg_type
, "savings_plan_amortized_upfront_commitment_for_billing_period" sp_amortised_upfront_commitment
, "savings_plan_recurring_commitment_for_billing_period" sp_recurring_commitment
, "savings_plan_savings_plan_effective_cost" sp_effective_cost
, "savings_plan_region" sp_region
, "savings_plan_purchase_term" term_length
, "savings_plan_payment_option" payment_options
, "savings_plan_offering_type" sp_type
, CASE 
  	WHEN line_item_product_code = 'AmazonECS' THEN 'Fargate'
  	WHEN line_item_product_code = 'AWSLambda' THEN 'Lambda'
  	ELSE product_instance_type_family 
  END AS instance_type_family
, substr("reservation_reservation_a_r_n", strpos("reservation_reservation_a_r_n",'/')+1) reserved_arn
, (CASE WHEN "reservation_start_time" <> '' THEN substr("reservation_start_time", 1,10) ELSE '' END) reserved_start_date
, (CASE WHEN "reservation_end_time" <> '' THEN substr("reservation_end_time", 1,10) ELSE '' END) reserved_end_date
, (CASE WHEN ((TRY_CAST("month" AS integer) < 10) AND ("substring"("month", 1, 1) <> '0')) THEN "concat"("year", ' - ', '0', "month") ELSE "concat"("year", ' - ', "month") END) period
, (CASE 
    WHEN ("savings_plan_savings_plan_a_r_n" <> '' AND TRY_CAST(substr("savings_plan_end_time", 1,10) as date) >= current_date) THEN 'Active'  
    WHEN ("savings_plan_savings_plan_a_r_n" <> '' AND TRY_CAST(substr("savings_plan_end_time", 1,10) as date) < current_date) THEN 'Retired'
    ELSE ''  
    END) sp_status
, "sum"((CASE WHEN (((line_item_product_code = 'AmazonEC2')) AND (pricing_term LIKE '')) THEN CAST(line_item_usage_amount AS double) ELSE 0 END)) Spot_Usage
, "sum"((CASE WHEN (((line_item_product_code = 'AmazonEC2')) AND (pricing_term LIKE '')) THEN CAST(line_item_unblended_cost AS decimal(16,8)) ELSE 0 END)) Spot_Cost

, "sum"((CASE WHEN (((line_item_product_code = 'AmazonEC2')) AND (pricing_term LIKE 'Reserved')) THEN TRY_CAST(line_item_usage_amount AS double) ELSE 0 END)) RI_Usage
, "sum"((CASE WHEN (((line_item_product_code = 'AmazonEC2')) AND (pricing_term LIKE 'Reserved')) THEN TRY_CAST("reservation_effective_cost" AS decimal(16,8)) ELSE 0 END)) RI_Cost

, "sum"((CASE WHEN ((line_item_product_code = 'AmazonEC2')) THEN (CASE line_item_line_item_type WHEN 'SavingsPlanCoveredUsage' THEN CAST(line_item_usage_amount AS double) ELSE 0 END) ELSE 0 END)) SavingsPlans_Usage
, "sum"((CASE WHEN ((line_item_product_code = 'AmazonEC2')) THEN (CASE line_item_line_item_type WHEN 'SavingsPlanCoveredUsage' THEN CAST("savings_plan_savings_plan_effective_cost" AS decimal(16,8)) ELSE 0 END) ELSE 0 END)) SavingsPlans_Cost
, "sum"((CASE WHEN ((line_item_product_code = 'AmazonEC2')) THEN (CASE line_item_line_item_type WHEN 'SavingsPlanCoveredUsage' THEN CAST("line_item_unblended_cost" AS decimal(16,8)) ELSE 0 END) ELSE 0 END)) OnDemand_SP_Cost

, "sum"((CASE WHEN (((line_item_product_code = 'AmazonEC2')) AND (pricing_term LIKE 'OnDemand')) THEN (CASE line_item_line_item_type WHEN 'Usage' THEN CAST(line_item_usage_amount AS double) ELSE 0 END) ELSE 0 END)) OnDemand_Usage
, "sum"((CASE WHEN (((line_item_product_code = 'AmazonEC2')) AND (pricing_term LIKE 'OnDemand')) THEN (CASE line_item_line_item_type WHEN 'Usage' THEN CAST(line_item_unblended_cost AS decimal(16,8)) ELSE 0 END) ELSE 0 END)) OnDemand_Cost

, "sum"(CASE WHEN (TRY_CAST("savings_plan_savings_plan_rate" AS decimal(16,8)) > 0E0) THEN (TRY_CAST("line_item_unblended_cost" AS decimal(16,8)) - TRY_CAST("savings_plan_savings_plan_effective_cost" AS decimal(16,8))) ELSE 0E0 END) SP_savings
, "sum"((CASE WHEN (line_item_product_code LIKE '%SavingsPlans%') THEN CAST(line_item_unblended_cost AS double) ELSE 0 END)) SP_Plan_Cost
, "sum"(CASE WHEN (TRY_CAST("line_item_unblended_cost" AS decimal(16,8)) > 0E0) THEN ((TRY_CAST("line_item_unblended_cost" AS decimal(16,8)) - TRY_CAST("savings_plan_savings_plan_effective_cost" AS decimal(16,8))) / TRY_CAST("line_item_unblended_cost" AS decimal(16,8))) ELSE 0E0 END) SP_percentage_savings

, "sum"((CASE WHEN (((line_item_product_code  = 'AmazonEC2')) AND (pricing_term LIKE 'Reserved')) THEN CAST("reservation_upfront_value" AS double) ELSE 0 END)) reserved_upfront
, "sum"(CASE WHEN (((line_item_product_code  = 'AmazonEC2')) AND pricing_term LIKE 'Reserved' AND "reservation_reservation_a_r_n" <>'') THEN ((TRY_CAST("line_item_unblended_rate" AS decimal(16,8)) * TRY_CAST(line_item_usage_amount AS double))) ELSE 0E0 END) On_Demand_RI_Cost
, "sum"(CASE WHEN (((line_item_product_code  = 'AmazonEC2')) AND pricing_term LIKE 'Reserved' AND "reservation_reservation_a_r_n" <>'') THEN TRY_CAST("reservation_effective_cost" AS decimal(16,8)) ELSE 0E0 END) Reserved_Cost
, "sum"(CASE WHEN (((line_item_product_code  = 'AmazonEC2')) AND pricing_term LIKE 'Reserved' AND "reservation_reservation_a_r_n" <>'' AND TRY_CAST("reservation_effective_cost" AS decimal(16,8))<> 0E0) THEN ((TRY_CAST("line_item_unblended_rate" AS decimal(16,8)) * TRY_CAST(line_item_usage_amount AS double)) - TRY_CAST("reservation_effective_cost" AS decimal(16,8))) ELSE 0E0 END) On_Demand_Reserved_savings
FROM
  "customer_all"
WHERE (line_item_product_code = 'AmazonEC2' AND line_item_operation LIKE '%RunInstance%') 
OR (line_item_product_code LIKE '%SavingsPlans%')
OR line_item_product_code = 'AmazonECS'
OR line_item_product_code = 'AWSLambda'
GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41
