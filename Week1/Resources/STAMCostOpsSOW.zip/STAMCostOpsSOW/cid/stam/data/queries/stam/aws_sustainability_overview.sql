-- Create a sustainability view for the aws_sustainability_overview
CREATE OR REPLACE VIEW "aws_sustainability_overview" AS 
SELECT
  "mth0_bill_payer_account_id"
, "mth0_linked_acct_id"
, "mth0_prod_code"
, "mth0_region"
, "mth0_servicecode"
, "mth0_operation"
, "mth0_usage_type"
, "mth0_charge_type"
, "mth0_pricing_term"
, "mth0_clock_speed"
, "mth0_inst_family"
, "mth0_instance"
, "mth0_instance_type_family"
, "mth0_vcpu_count"
, "mth0_year"
, "mth0_month"
, "mth0_instance_id"
, "mth0_instance_family"
, "mth0_r_points"
, "mth0_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth0_month AS integer) < 10) AND ("substring"(mth0_month, 1, 1) <> '0')) 
THEN "concat"(mth0_year, ' - ','0',  mth0_month) ELSE "concat"(mth0_year, ' - ', mth0_month) END) period
, (CASE WHEN ((TRY_CAST(mth0_month AS integer) < 10) AND ("substring"(mth0_month, 1, 1) <> '0')) 
THEN "concat"('0', mth0_month) ELSE mth0_month END) mth_order

FROM
  join_mth_0_mth_1_vcpu_hours
UNION ALL SELECT
  "mth1_bill_payer_account_id"
, "mth1_linked_acct_id"
, "mth1_prod_code"
, "mth1_region"
, "mth1_servicecode"
, "mth1_operation"
, "mth1_usage_type"
, "mth1_charge_type"
, "mth1_pricing_term"
, "mth1_clock_speed"
, "mth1_inst_family"
, "mth1_instance"
, "mth1_instance_type_family"
, "mth1_vcpu_count"
, "mth1_year"
, "mth1_month"
, "mth1_instance_id"
, "mth1_instance_family"
, "mth1_r_points"
, "mth1_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth1_month AS integer) < 10) AND ("substring"(mth1_month, 1, 1) <> '0')) 
THEN "concat"(mth1_year, ' - ','0',  mth1_month) ELSE "concat"(mth1_year, ' - ', mth1_month) END) period
, (CASE WHEN ((TRY_CAST(mth1_month AS integer) < 10) AND ("substring"(mth1_month, 1, 1) <> '0')) 
THEN "concat"('0', mth1_month) ELSE mth1_month END) mth_order

FROM
  join_mth_1_mth_2_vcpu_hours
UNION ALL SELECT
  "mth2_bill_payer_account_id"
, "mth2_linked_acct_id"
, "mth2_prod_code"
, "mth2_region"
, "mth2_servicecode"
, "mth2_operation"
, "mth2_usage_type"
, "mth2_charge_type"
, "mth2_pricing_term"
, "mth2_clock_speed"
, "mth2_inst_family"
, "mth2_instance"
, "mth2_instance_type_family"
, "mth2_vcpu_count"
, "mth2_year"
, "mth2_month"
, "mth2_instance_id"
, "mth2_instance_family"
, "mth2_r_points"
, "mth2_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth2_month AS integer) < 10) AND ("substring"(mth2_month, 1, 1) <> '0')) 
THEN "concat"(mth2_year, ' - ','0',  mth2_month) ELSE "concat"(mth2_year, ' - ', mth2_month) END) period
, (CASE WHEN ((TRY_CAST(mth2_month AS integer) < 10) AND ("substring"(mth2_month, 1, 1) <> '0')) 
THEN "concat"('0', mth2_month) ELSE mth2_month END) mth_order

FROM
  join_mth_2_mth_3_vcpu_hours
UNION ALL SELECT
  "mth3_bill_payer_account_id"
, "mth3_linked_acct_id"
, "mth3_prod_code"
, "mth3_region"
, "mth3_servicecode"
, "mth3_operation"
, "mth3_usage_type"
, "mth3_charge_type"
, "mth3_pricing_term"
, "mth3_clock_speed"
, "mth3_inst_family"
, "mth3_instance"
, "mth3_instance_type_family"
, "mth3_vcpu_count"
, "mth3_year"
, "mth3_month"
, "mth3_instance_id"
, "mth3_instance_family"
, "mth3_r_points"
, "mth3_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth3_month AS integer) < 10) AND ("substring"(mth3_month, 1, 1) <> '0')) 
THEN "concat"(mth3_year, ' - ','0',  mth3_month) ELSE "concat"(mth3_year, ' - ', mth3_month) END) period
, (CASE WHEN ((TRY_CAST(mth3_month AS integer) < 10) AND ("substring"(mth3_month, 1, 1) <> '0')) 
THEN "concat"('0', mth3_month) ELSE mth3_month END) mth_order

FROM
  join_mth_3_mth_4_vcpu_hours
UNION ALL SELECT
  "mth4_bill_payer_account_id"
, "mth4_linked_acct_id"
, "mth4_prod_code"
, "mth4_region"
, "mth4_servicecode"
, "mth4_operation"
, "mth4_usage_type"
, "mth4_charge_type"
, "mth4_pricing_term"
, "mth4_clock_speed"
, "mth4_inst_family"
, "mth4_instance"
, "mth4_instance_type_family"
, "mth4_vcpu_count"
, "mth4_year"
, "mth4_month"
, "mth4_instance_id"
, "mth4_instance_family"
, "mth4_r_points"
, "mth4_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth4_month AS integer) < 10) AND ("substring"(mth4_month, 1, 1) <> '0')) 
THEN "concat"( mth4_year, ' - ','0', mth4_month) ELSE "concat"(mth4_year, ' - ', mth4_month) END) period
, (CASE WHEN ((TRY_CAST(mth4_month AS integer) < 10) AND ("substring"(mth4_month, 1, 1) <> '0')) 
THEN "concat"('0', mth4_month) ELSE mth4_month END) mth_order

FROM
  join_mth_4_mth_5_vcpu_hours
UNION ALL SELECT
  "mth5_bill_payer_account_id"
, "mth5_linked_acct_id"
, "mth5_prod_code"
, "mth5_region"
, "mth5_servicecode"
, "mth5_operation"
, "mth5_usage_type"
, "mth5_charge_type"
, "mth5_pricing_term"
, "mth5_clock_speed"
, "mth5_inst_family"
, "mth5_instance"
, "mth5_instance_type_family"
, "mth5_vcpu_count"
, "mth5_year"
, "mth5_month"
, "mth5_instance_id"
, "mth5_instance_family"
, "mth5_r_points"
, "mth5_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth5_month AS integer) < 10) AND ("substring"(mth5_month, 1, 1) <> '0')) 
THEN "concat"(mth5_year, ' - ','0',  mth5_month) ELSE "concat"(mth5_year, ' - ', mth5_month) END) period
, (CASE WHEN ((TRY_CAST(mth5_month AS integer) < 10) AND ("substring"(mth5_month, 1, 1) <> '0')) 
THEN "concat"('0', mth5_month) ELSE mth5_month END) mth_order

FROM
  join_mth_5_mth_6_vcpu_hours
UNION ALL SELECT
  "mth6_bill_payer_account_id"
, "mth6_linked_acct_id"
, "mth6_prod_code"
, "mth6_region"
, "mth6_servicecode"
, "mth6_operation"
, "mth6_usage_type"
, "mth6_charge_type"
, "mth6_pricing_term"
, "mth6_clock_speed"
, "mth6_inst_family"
, "mth6_instance"
, "mth6_instance_type_family"
, "mth6_vcpu_count"
, "mth6_year"
, "mth6_month"
, "mth6_instance_id"
, "mth6_instance_family"
, "mth6_r_points"
, "mth6_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth6_month AS integer) < 10) AND ("substring"(mth6_month, 1, 1) <> '0')) 
THEN "concat"( mth6_year, ' - ','0', mth6_month) ELSE "concat"(mth6_year, ' - ', mth6_month) END) period
, (CASE WHEN ((TRY_CAST(mth6_month AS integer) < 10) AND ("substring"(mth6_month, 1, 1) <> '0')) 
THEN "concat"('0', mth6_month) ELSE mth6_month END) mth_order

FROM
  join_mth_6_mth_7_vcpu_hours
UNION ALL SELECT
  "mth7_bill_payer_account_id"
, "mth7_linked_acct_id"
, "mth7_prod_code"
, "mth7_region"
, "mth7_servicecode"
, "mth7_operation"
, "mth7_usage_type"
, "mth7_charge_type"
, "mth7_pricing_term"
, "mth7_clock_speed"
, "mth7_inst_family"
, "mth7_instance"
, "mth7_instance_type_family"
, "mth7_vcpu_count"
, "mth7_year"
, "mth7_month"
, "mth7_instance_id"
, "mth7_instance_family"
, "mth7_r_points"
, "mth7_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth7_month AS integer) < 10) AND ("substring"(mth7_month, 1, 1) <> '0')) 
THEN "concat"( mth7_year, ' - ','0', mth7_month) ELSE "concat"(mth7_year, ' - ', mth7_month) END) period
, (CASE WHEN ((TRY_CAST(mth7_month AS integer) < 10) AND ("substring"(mth7_month, 1, 1) <> '0')) 
THEN "concat"('0', mth7_month) ELSE mth7_month END) mth_order

FROM
  join_mth_7_mth_8_vcpu_hours
UNION ALL SELECT
  "mth8_bill_payer_account_id"
, "mth8_linked_acct_id"
, "mth8_prod_code"
, "mth8_region"
, "mth8_servicecode"
, "mth8_operation"
, "mth8_usage_type"
, "mth8_charge_type"
, "mth8_pricing_term"
, "mth8_clock_speed"
, "mth8_inst_family"
, "mth8_instance"
, "mth8_instance_type_family"
, "mth8_vcpu_count"
, "mth8_year"
, "mth8_month"
, "mth8_instance_id"
, "mth8_instance_family"
, "mth8_r_points"
, "mth8_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth8_month AS integer) < 10) AND ("substring"(mth8_month, 1, 1) <> '0')) 
THEN "concat"(mth8_year, ' - ','0',  mth8_month) ELSE "concat"(mth8_year, ' - ', mth8_month) END) period
, (CASE WHEN ((TRY_CAST(mth8_month AS integer) < 10) AND ("substring"(mth8_month, 1, 1) <> '0')) 
THEN "concat"('0', mth8_month) ELSE mth8_month END) mth_order

FROM
  join_mth_8_mth_9_vcpu_hours
UNION ALL SELECT
  "mth9_bill_payer_account_id"
, "mth9_linked_acct_id"
, "mth9_prod_code"
, "mth9_region"
, "mth9_servicecode"
, "mth9_operation"
, "mth9_usage_type"
, "mth9_charge_type"
, "mth9_pricing_term"
, "mth9_clock_speed"
, "mth9_inst_family"
, "mth9_instance"
, "mth9_instance_type_family"
, "mth9_vcpu_count"
, "mth9_year"
, "mth9_month"
, "mth9_instance_id"
, "mth9_instance_family"
, "mth9_r_points"
, "mth9_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth9_month AS integer) < 10) AND ("substring"(mth9_month, 1, 1) <> '0')) 
THEN "concat"(mth9_year, ' - ','0',  mth9_month) ELSE "concat"(mth9_year, ' - ', mth9_month) END) period
, (CASE WHEN ((TRY_CAST(mth9_month AS integer) < 10) AND ("substring"(mth9_month, 1, 1) <> '0')) 
THEN "concat"('0', mth9_month) ELSE mth9_month END) mth_order

FROM
  join_mth_9_mth_10_vcpu_hours
UNION ALL SELECT
  "mth10_bill_payer_account_id"
, "mth10_linked_acct_id"
, "mth10_prod_code"
, "mth10_region"
, "mth10_servicecode"
, "mth10_operation"
, "mth10_usage_type"
, "mth10_charge_type"
, "mth10_pricing_term"
, "mth10_clock_speed"
, "mth10_inst_family"
, "mth10_instance"
, "mth10_instance_type_family"
, "mth10_vcpu_count"
, "mth10_year"
, "mth10_month"
, "mth10_instance_id"
, "mth10_instance_family"
, "mth10_r_points"
, "mth10_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth10_month AS integer) < 10) AND ("substring"(mth10_month, 1, 1) <> '0')) 
THEN "concat"(mth10_year, ' - ','0',  mth10_month) ELSE "concat"(mth10_year, ' - ', mth10_month) END) period
, (CASE WHEN ((TRY_CAST(mth10_month AS integer) < 10) AND ("substring"(mth10_month, 1, 1) <> '0')) 
THEN "concat"('0', mth10_month) ELSE mth10_month END) mth_order

FROM
  join_mth_10_mth_11_vcpu_hours
UNION ALL SELECT
  "mth11_bill_payer_account_id"
, "mth11_linked_acct_id"
, "mth11_prod_code"
, "mth11_region"
, "mth11_servicecode"
, "mth11_operation"
, "mth11_usage_type"
, "mth11_charge_type"
, "mth11_pricing_term"
, "mth11_clock_speed"
, "mth11_inst_family"
, "mth11_instance"
, "mth11_instance_type_family"
, "mth11_vcpu_count"
, "mth11_year"
, "mth11_month"
, "mth11_instance_id"
, "mth11_instance_family"
, "mth11_r_points"
, "mth11_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth11_month AS integer) < 10) AND ("substring"(mth11_month, 1, 1) <> '0')) 
THEN "concat"( mth11_year, ' - ','0', mth11_month) ELSE "concat"(mth11_year, ' - ', mth11_month) END) period
, (CASE WHEN ((TRY_CAST(mth11_month AS integer) < 10) AND ("substring"(mth11_month, 1, 1) <> '0')) 
THEN "concat"('0', mth11_month) ELSE mth11_month END) mth_order

FROM
  join_mth_11_mth_12_vcpu_hours
UNION ALL SELECT
  "mth12_bill_payer_account_id"
, "mth12_linked_acct_id"
, "mth12_prod_code"
, "mth12_region"
, "mth12_servicecode"
, "mth12_operation"
, "mth12_usage_type"
, "mth12_charge_type"
, "mth12_pricing_term"
, "mth12_clock_speed"
, "mth12_inst_family"
, "mth12_instance"
, "mth12_instance_type_family"
, "mth12_vcpu_count"
, "mth12_year"
, "mth12_month"
, "mth12_instance_id"
, "mth12_instance_family"
, "mth12_r_points"
, "mth12_instance_points"
, "cur_mth_instance_hrs"
, "cur_mth_od_cost"
, "cur_mth_sp_cost"
, "cur_mth_vcpu_hours"
, "cur_mth_spot_vcpu_hours"
, "cur_mth_ec2_sustainability_points" total_sus_pts
, "cur_mth_instance_cost" total_instance_cost
, "cur_mth_Cost_per_Sus_Point"
, "od_savings"
, "od_inc_cost"
, "sp_savings"
, "sp_inc_cost"
, "inc_vcpu_hours"
, "savings_vcpu_hours"
, "inc_spot_vcpu_hours"
, "savings_spot_vcpu_hours"
, "inc_ec2_sustainability_points"
, "savings_ec2_sustainability_points" total_reduction_sus_pts
, "inc_instance_cost"
, "savings_instance_cost" total_ec2_savings
, "inc_Cost_per_Sus_Point"
, "savings_Cost_per_Sus_Point"
, (CASE WHEN ((TRY_CAST(mth12_month AS integer) < 10) AND ("substring"(mth12_month, 1, 1) <> '0')) 
THEN "concat"( mth12_year, ' - ','0', mth12_month) ELSE "concat"(mth12_year, ' - ', mth12_month) END) period
, (CASE WHEN ((TRY_CAST(mth12_month AS integer) < 10) AND ("substring"(mth12_month, 1, 1) <> '0')) 
THEN "concat"('0', mth12_month) ELSE mth12_month END) mth_order

FROM
  join_mth_12_mth_13_vcpu_hours

-- end of create view