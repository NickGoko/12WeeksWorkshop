-- Create a view for Storage by Class
CREATE OR REPLACE VIEW "view_storage_by_class" AS 
SELECT
  "line_item_usage_account_id" linked_account_id
    , "date_trunc"('hour', line_item_usage_end_date) end_date
    , "line_item_resource_id" resource_id
    , "bill_payer_account_id" payer
    , "line_item_line_item_type" charge_type
    , "line_item_line_item_description" description
    , "line_item_operation" operation
    , "product_volume_type" storage_class
    , "year"
    , "month"
    , "line_item_product_code"
    , "sum"(CAST(line_item_usage_amount AS double)) usage_gb
    , "sum"(line_item_unblended_cost) unblended_cost
FROM
  ${cur_table_name}
WHERE (((product_servicename LIKE '%Amazon Simple Storage Service%') AND (NOT (product_volume_type LIKE ''))) AND (NOT (product_volume_type LIKE 'Tags')))
GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11
-- end of create view