-- Create a S3 storage view for the join_month_0_S3_month_0_top_10_s3
CREATE OR REPLACE VIEW "join_month_0_S3_month_0_top_10_s3" AS 
SELECT DISTINCT
  view_0.bill_payer_account_id
, view_0.linked_acct_id
, view_0.prod_code
, view_0.region
, view_0.description
, view_0.unblended_rate
, view_0.storage_class
, view_0.servicecode
, view_0.operation
, view_0.usage_type
, view_0.charge_type
, view_0.year
, view_0.month
, view_0.period
, view_0.mth_order
, view_0.bucket_id
, view_0.usage
, view_0.bucket_cost
, view_0_top_10.line_item_usage_account_id
FROM
  (view_s3_month_0 view_0
INNER JOIN view_s3_month_0_top_10_accts view_0_top_10 ON (view_0.linked_acct_id = view_0_top_10.line_item_usage_account_id))

-- end of create view