-- Create a S3 storage view for the join_month_05_S3_month_05_top_10_s3
CREATE OR REPLACE VIEW "join_month_05_S3_month_05_top_10_s3" AS 
SELECT DISTINCT
  view_05.bill_payer_account_id
, view_05.linked_acct_id
, view_05.prod_code
, view_05.region
, view_05.description
, view_05.unblended_rate
, view_05.storage_class
, view_05.servicecode
, view_05.operation
, view_05.usage_type
, view_05.charge_type
, view_05.year
, view_05.month
, view_05.period
, view_05.mth_order
, view_05.bucket_id
, view_05.usage
, view_05.bucket_cost
, view_05_top_10.line_item_usage_account_id
FROM
  (view_s3_month_05 view_05
INNER JOIN view_s3_month_05_top_10_accts view_05_top_10 ON (view_05.linked_acct_id = view_05_top_10.line_item_usage_account_id))

-- end of create view