-- Create a S3 storage view for the join_month_02_S3_month_02_top_10_s3
CREATE OR REPLACE VIEW "join_month_02_S3_month_02_top_10_s3" AS 
SELECT DISTINCT
  view_02.bill_payer_account_id
, view_02.linked_acct_id
, view_02.prod_code
, view_02.region
, view_02.description
, view_02.unblended_rate
, view_02.storage_class
, view_02.servicecode
, view_02.operation
, view_02.usage_type
, view_02.charge_type
, view_02.year
, view_02.month
, view_02.period
, view_02.mth_order
, view_02.bucket_id
, view_02.usage
, view_02.bucket_cost
, view_02_top_10.line_item_usage_account_id
FROM
  (view_s3_month_02 view_02
INNER JOIN view_s3_month_02_top_10_accts view_02_top_10 ON (view_02.linked_acct_id = view_02_top_10.line_item_usage_account_id))

-- end of create view