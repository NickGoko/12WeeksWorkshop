-- Create a S3 storage view for the join_month_03_S3_month_03_top_10_s3
CREATE OR REPLACE VIEW "join_month_03_S3_month_03_top_10_s3" AS 
SELECT DISTINCT
  view_03.bill_payer_account_id
, view_03.linked_acct_id
, view_03.prod_code
, view_03.region
, view_03.description
, view_03.unblended_rate
, view_03.storage_class
, view_03.servicecode
, view_03.operation
, view_03.usage_type
, view_03.charge_type
, view_03.year
, view_03.month
, view_03.period
, view_03.mth_order
, view_03.bucket_id
, view_03.usage
, view_03.bucket_cost
, view_03_top_10.line_item_usage_account_id
FROM
  (view_s3_month_03 view_03
INNER JOIN view_s3_month_03_top_10_accts view_03_top_10 ON (view_03.linked_acct_id = view_03_top_10.line_item_usage_account_id))

-- end of create view