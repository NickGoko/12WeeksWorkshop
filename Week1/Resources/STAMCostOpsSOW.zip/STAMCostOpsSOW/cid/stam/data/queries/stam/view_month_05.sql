-- Create a view for the 5th prior month
CREATE OR REPLACE VIEW "view_month_05" AS 
SELECT DISTINCT
  month_5."bill_payer_account_id" mth5_bill_payer_account_id
  , month_5."line_item_usage_account_id" mth5_linked_acct_id
  , month_5."line_item_product_code" mth5_prod_code
  , month_5."line_item_resource_id" mth5_resource_id
  , month_5."line_item_line_item_description" mth5_description
  , month_5."line_item_line_item_type" mth5_charge_type
  , month_5."line_item_operation" mth5_operation
  , month_5."line_item_unblended_rate" mth5_unblended_rate
  , month_5."product_instance_type" mth5_instance
  , month_5."product_product_family" mth5_prod_family
  , month_5."product_instance_family" mth5_instance_family
  , month_5."product_instance_type" mth5_instance_type
  , month_5."product_instance_type_family" mth5_instance_type_family
  , month_5."product_tenancy" mth5_tenancy
  , month_5."product_location" mth5_region
  , month_5."product_location_type" mth5_location_type
  , month_5."product_operating_system" mth5_operating_system
--  , month_5."savings_plan_region" mth5_sp_region
--  , month_5."savings_plan_purchase_term" mth5_term_length
--  , month_5."savings_plan_payment_option" mth5_payment_options
--  , month_5."savings_plan_offering_type" mth5_sp_type
  , month_5."savings_plan_savings_plan_a_r_n" mth5_sp_arn
  , month_5."savings_plan_savings_plan_rate" mth5_sp_rate
  , month_5."product_volume_type" mth5_storage_class
  , "sum"(TRY_CAST(month_5."line_item_unblended_cost" AS decimal(16,8))) month_5_cost
  , "sum"(TRY_CAST(month_5."line_item_usage_amount" AS decimal(16,8))) month_5_usage
  , month_5."year" mth5_year
  , month_5."month" mth5_month
  , month_5."bill_payer_account_id" mth5_payer
FROM
  "customer_all" month_5
WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '5' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '5' MONTH))) AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '4' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '4' MONTH))))
GROUP BY "bill_payer_account_id"
  , "line_item_usage_account_id"
  , "line_item_product_code"
  , "line_item_resource_id"
  , "line_item_line_item_description"
  , "line_item_line_item_type"
  , "line_item_operation"
  , "line_item_unblended_rate"
  , "product_instance_type"
  , "product_product_family"
  , "savings_plan_savings_plan_a_r_n"
  , "savings_plan_savings_plan_rate"
  , "product_volume_type"
  , "year"
  , "month"
  , "product_instance_type_family"
  , "product_tenancy"
  , "product_location"
  , "product_location_type"
  , "product_operating_system"
--  , "savings_plan_region"
--  , "savings_plan_purchase_term"
--  , "savings_plan_payment_option"
--  , "savings_plan_offering_type"
  , "product_instance_family"
  , "product_instance_type"
-- end of create view