-- Create a S3 storage view for the join_month_06_S3_month_06_top_10_s3
CREATE OR REPLACE VIEW "join_month_06_S3_month_06_top_10_s3" AS 
SELECT DISTINCT
  view_06.bill_payer_account_id
, view_06.linked_acct_id
, view_06.prod_code
, view_06.region
, view_06.description
, view_06.unblended_rate
, view_06.storage_class
, view_06.servicecode
, view_06.operation
, view_06.usage_type
, view_06.charge_type
, view_06.year
, view_06.month
, view_06.period
, view_06.mth_order
, view_06.bucket_id
, view_06.usage
, view_06.bucket_cost
, view_06_top_10.line_item_usage_account_id
FROM
  (view_s3_month_06 view_06
INNER JOIN view_s3_month_06_top_10_accts view_06_top_10 ON (view_06.linked_acct_id = view_06_top_10.line_item_usage_account_id))

-- end of create view