-- Create a S3 storage view for the join_month_04_S3_month_04_top_10_s3
CREATE OR REPLACE VIEW "join_month_04_S3_month_04_top_10_s3" AS 
SELECT DISTINCT
  view_04.bill_payer_account_id
, view_04.linked_acct_id
, view_04.prod_code
, view_04.region
, view_04.description
, view_04.unblended_rate
, view_04.storage_class
, view_04.servicecode
, view_04.operation
, view_04.usage_type
, view_04.charge_type
, view_04.year
, view_04.month
, view_04.period
, view_04.mth_order
, view_04.bucket_id
, view_04.usage
, view_04.bucket_cost
, view_04_top_10.line_item_usage_account_id
FROM
  (view_s3_month_04 view_04
INNER JOIN view_s3_month_04_top_10_accts view_04_top_10 ON (view_04.linked_acct_id = view_04_top_10.line_item_usage_account_id))

-- end of create view