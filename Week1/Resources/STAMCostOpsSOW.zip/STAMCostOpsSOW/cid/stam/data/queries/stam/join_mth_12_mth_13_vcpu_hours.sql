-- Create a sustainability view for the join_mth_12_mth_13_vcpu_hours
CREATE OR REPLACE VIEW "join_mth_12_mth_13_vcpu_hours" AS 
SELECT
-- Select from view_month_12
  view_month_12_vcpu_hours.mth12_bill_payer_account_id
, view_month_12_vcpu_hours.mth12_linked_acct_id
, view_month_12_vcpu_hours.mth12_prod_code
, view_month_12_vcpu_hours.mth12_region
, view_month_12_vcpu_hours.mth12_servicecode
, view_month_12_vcpu_hours.mth12_operation
, view_month_12_vcpu_hours.mth12_usage_type
, view_month_12_vcpu_hours.mth12_charge_type
, view_month_12_vcpu_hours.mth12_pricing_term
, view_month_12_vcpu_hours.mth12_clock_speed
, view_month_12_vcpu_hours.mth12_inst_family
, view_month_12_vcpu_hours.mth12_instance
, view_month_12_vcpu_hours.mth12_instance_type_family
, view_month_12_vcpu_hours.mth12_vcpu_count
, view_month_12_vcpu_hours.mth12_year
, view_month_12_vcpu_hours.mth12_month
, view_month_12_vcpu_hours.mth12_instance_id
, view_month_12_vcpu_hours.mth12_instance_family
, view_month_12_vcpu_hours.mth12_r_points
, view_month_12_vcpu_hours.mth12_instance_points
-- Select from view_month_13
,  view_month_13_vcpu_hours.mth13_bill_payer_account_id
, view_month_13_vcpu_hours.mth13_linked_acct_id
, view_month_13_vcpu_hours.mth13_prod_code
, view_month_13_vcpu_hours.mth13_region
, view_month_13_vcpu_hours.mth13_servicecode
, view_month_13_vcpu_hours.mth13_operation
, view_month_13_vcpu_hours.mth13_usage_type
, view_month_13_vcpu_hours.mth13_charge_type
, view_month_13_vcpu_hours.mth13_pricing_term
, view_month_13_vcpu_hours.mth13_clock_speed
, view_month_13_vcpu_hours.mth13_inst_family
, view_month_13_vcpu_hours.mth13_instance
, view_month_13_vcpu_hours.mth13_instance_type_family
, view_month_13_vcpu_hours.mth13_vcpu_count
, view_month_13_vcpu_hours.mth13_year
, view_month_13_vcpu_hours.mth13_month
, view_month_13_vcpu_hours.mth13_instance_id
, view_month_13_vcpu_hours.mth13_instance_family
, view_month_13_vcpu_hours.mth13_r_points
, view_month_13_vcpu_hours.mth13_instance_points

, TRY_CAST(view_month_12_vcpu_hours.mth12_instance_hours AS decimal(16,8)) cur_mth_instance_hrs
, TRY_CAST(view_month_12_vcpu_hours.mth12_od_instance_cost AS decimal(16,8)) cur_mth_od_cost
, TRY_CAST(view_month_12_vcpu_hours.mth12_sp_instance_cost AS decimal(16,8)) cur_mth_sp_cost

, TRY_CAST(view_month_13_vcpu_hours.mth13_instance_hours AS decimal(16,8)) prev_mth_instance_hrs
, TRY_CAST(view_month_13_vcpu_hours.mth13_od_instance_cost AS decimal(16,8)) prev_mth_od_cost
, TRY_CAST(view_month_13_vcpu_hours.mth13_sp_instance_cost AS decimal(16,8)) prev_mth_sp_cost

, (TRY_CAST(view_month_12_vcpu_hours.mth12_instance_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_instance_hours AS decimal(16,8))) instance_hrs_var
, (TRY_CAST(view_month_12_vcpu_hours.mth12_od_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_od_instance_cost AS decimal(16,8))) od_cost_var
, (TRY_CAST(view_month_12_vcpu_hours.mth12_sp_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_sp_instance_cost AS decimal(16,8))) sp_cost_var

-- total metrics

, TRY_CAST(view_month_12_vcpu_hours.mth12_vcpu_hours AS decimal(16,8)) cur_mth_vcpu_hours
, TRY_CAST(view_month_12_vcpu_hours.mth12_spot_vcpu_hours AS decimal(16,8)) cur_mth_spot_vcpu_hours
, TRY_CAST(view_month_12_vcpu_hours.mth12_ec2_sustainability_points AS decimal(16,8)) cur_mth_ec2_sustainability_points
, TRY_CAST(view_month_12_vcpu_hours.mth12_instance_cost AS decimal(16,8)) cur_mth_instance_cost
, TRY_CAST(view_month_12_vcpu_hours.mth12_Cost_per_Sus_Point AS decimal(16,8)) cur_mth_Cost_per_Sus_Point

, TRY_CAST(view_month_13_vcpu_hours.mth13_vcpu_hours AS decimal(16,8)) prev_mth_vcpu_hours
, TRY_CAST(view_month_13_vcpu_hours.mth13_spot_vcpu_hours AS decimal(16,8)) prev_mth_spot_vcpu_hours
, TRY_CAST(view_month_13_vcpu_hours.mth13_ec2_sustainability_points AS decimal(16,8)) prev_mth_ec2_sustainability_points
, TRY_CAST(view_month_13_vcpu_hours.mth13_instance_cost AS decimal(16,8)) prev_mth_instance_cost
, TRY_CAST(view_month_13_vcpu_hours.mth13_Cost_per_Sus_Point AS decimal(16,8)) prev_mth_Cost_per_Sus_Point


-- end


, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_od_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_od_instance_cost AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_od_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_od_instance_cost AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) od_savings

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_od_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_od_instance_cost AS decimal(16,8))) > 0) 
	THEN TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_od_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_od_instance_cost AS decimal(16,8))) AS decimal(16,8)) 
	ELSE 0E0 
	END) od_inc_cost

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_sp_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_sp_instance_cost AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_sp_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_sp_instance_cost AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) sp_savings

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_sp_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_sp_instance_cost AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_sp_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_sp_instance_cost AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) sp_inc_cost

-- Calculate key metrics for sustainability


-- vcpu hours    
-- mth0_vcpu_hours
-- mth1_vcpu_hours

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_vcpu_hours AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_vcpu_hours AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_vcpu_hours
, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_vcpu_hours AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_vcpu_hours AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_vcpu_hours

-- spot vcpu hours    
-- mth0_spot_vcpu_hours
-- mth1_spot_vcpu_hours

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_spot_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_spot_vcpu_hours AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_spot_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_spot_vcpu_hours AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_spot_vcpu_hours
, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_spot_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_spot_vcpu_hours AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_spot_vcpu_hours AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_spot_vcpu_hours AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_spot_vcpu_hours

-- ec2 sustainability points    
-- mth0_ec2_sustainability_points
-- mth1_ec2_sustainability_points

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_ec2_sustainability_points AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_ec2_sustainability_points AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_ec2_sustainability_points AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_ec2_sustainability_points AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_ec2_sustainability_points
, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_ec2_sustainability_points AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_ec2_sustainability_points AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_ec2_sustainability_points AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_ec2_sustainability_points AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_ec2_sustainability_points

-- instance cost    
-- mth0_instance_cost
-- mth1_instance_cost

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_instance_cost AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_instance_cost AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_instance_cost
, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_instance_cost AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_instance_cost AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_instance_cost AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_instance_cost

-- cost per sustainability point    
-- mth0_Cost_per_Sus_Point
-- mth1_Cost_per_Sus_Point

, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_Cost_per_Sus_Point AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_Cost_per_Sus_Point AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_Cost_per_Sus_Point AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_Cost_per_Sus_Point AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_Cost_per_Sus_Point
, (CASE 
	WHEN ((TRY_CAST(view_month_12_vcpu_hours.mth12_Cost_per_Sus_Point AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_Cost_per_Sus_Point AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_12_vcpu_hours.mth12_Cost_per_Sus_Point AS decimal(16,8)) - TRY_CAST(view_month_13_vcpu_hours.mth13_Cost_per_Sus_Point AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_Cost_per_Sus_Point

-- end

FROM
 customer_cur_data.view_month_12_vcpu_hours

FULL JOIN view_month_13_vcpu_hours ON ((((((((((((((((((view_month_12_vcpu_hours.mth12_bill_payer_account_id = view_month_13_vcpu_hours.mth13_bill_payer_account_id) 
    AND (view_month_12_vcpu_hours.mth12_linked_acct_id = view_month_13_vcpu_hours.mth13_linked_acct_id)) 
    AND (view_month_12_vcpu_hours.mth12_prod_code = view_month_13_vcpu_hours.mth13_prod_code)) 
    AND (view_month_12_vcpu_hours.mth12_region = view_month_13_vcpu_hours.mth13_region)) 
    AND (view_month_12_vcpu_hours.mth12_servicecode = view_month_13_vcpu_hours.mth13_servicecode)) 
    AND (view_month_12_vcpu_hours.mth12_operation = view_month_13_vcpu_hours.mth13_operation)) 
    AND (view_month_12_vcpu_hours.mth12_usage_type = view_month_13_vcpu_hours.mth13_usage_type)) 
    AND (view_month_12_vcpu_hours.mth12_charge_type = view_month_13_vcpu_hours.mth13_charge_type)) 
    AND (view_month_12_vcpu_hours.mth12_pricing_term = view_month_13_vcpu_hours.mth13_pricing_term)) 
    AND (view_month_12_vcpu_hours.mth12_clock_speed = view_month_13_vcpu_hours.mth13_clock_speed)) 
    AND (view_month_12_vcpu_hours.mth12_inst_family = view_month_13_vcpu_hours.mth13_inst_family)) 
    AND (view_month_12_vcpu_hours.mth12_instance = view_month_13_vcpu_hours.mth13_instance)) 
    AND (view_month_12_vcpu_hours.mth12_instance_type_family = view_month_13_vcpu_hours.mth13_instance_type_family)) 
    AND (view_month_12_vcpu_hours.mth12_vcpu_count = view_month_13_vcpu_hours.mth13_vcpu_count)) 
    AND (view_month_12_vcpu_hours.mth12_instance_id = view_month_13_vcpu_hours.mth13_instance_id)) 
    AND (view_month_12_vcpu_hours.mth12_instance_family = view_month_13_vcpu_hours.mth13_instance_family)) 
    AND (view_month_12_vcpu_hours.mth12_r_points = view_month_13_vcpu_hours.mth13_r_points)) 
    AND (view_month_12_vcpu_hours.mth12_instance_points = view_month_13_vcpu_hours.mth13_instance_points))

GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
	, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65

-- end of create view