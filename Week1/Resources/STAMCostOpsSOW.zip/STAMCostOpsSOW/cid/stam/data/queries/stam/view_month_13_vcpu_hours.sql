-- Create a sustainability view for the 13th prior month
CREATE OR REPLACE VIEW "view_month_13_vcpu_hours" AS 
SELECT
  month_13."bill_payer_account_id" mth13_bill_payer_account_id
, month_13."line_item_usage_account_id" mth13_linked_acct_id
, month_13."line_item_product_code" mth13_prod_code
, month_13."product_region" mth13_region
, month_13."product_servicecode" mth13_servicecode
, month_13."line_item_operation" mth13_operation
, month_13."line_item_usage_type" mth13_usage_type
, month_13."line_item_line_item_type" mth13_charge_type
, month_13."pricing_term" mth13_pricing_term
, month_13."product_clock_speed" mth13_clock_speed
, month_13."product_instance_family" mth13_inst_family
, month_13."product_instance_type" mth13_instance
, month_13."product_instance_type_family" mth13_instance_type_family
, TRY_CAST(month_13."product_vcpu" AS int) mth13_vcpu_count
, month_13."year" mth13_year
, month_13."month" mth13_month
, month_13."line_item_resource_id" mth13_instance_id
, "split_part"(month_13."product_instance_type", '.', 1) mth13_instance_family
, (CASE 
	WHEN (((((month_13."product_region" = 'eu-west-1') 
	OR (month_13."product_region" = 'eu-central-1')) 
	OR (month_13."product_region" = 'ca-central-1')) 
	OR (month_13."product_region" = 'us-gov-west-1')) 
	OR (month_13."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END) mth13_r_points
, (CASE 
	WHEN ("split_part"(month_13."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END) mth13_instance_points
, "sum"(TRY_CAST(month_13."line_item_usage_amount" AS decimal(16,8))) mth13_instance_hours
, "sum"(TRY_CAST(month_13."line_item_unblended_cost" AS decimal(16,8))) mth13_od_instance_cost
, "sum"(TRY_CAST(month_13."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) mth13_sp_instance_cost

-- Calculate key metrics for sustainability

-- Key Metric: vcpu hours
, (TRY_CAST(month_13."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_13."line_item_usage_amount" AS decimal(16,8))))) mth13_vcpu_hours

-- Key Metric: spot vcpu hours
,(CASE 
	WHEN (month_13."pricing_term" = '')
	THEN (TRY_CAST(month_13."product_vcpu" AS int)*("sum"(TRY_CAST(month_13."line_item_usage_amount" AS decimal(16,8)))))
	ELSE 0
	END) mth13_spot_vcpu_hours

-- Key Metric: EC2 Sustainability Points
, (((TRY_CAST(month_13."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_13."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_13."product_region" = 'eu-west-1') 
	OR (month_13."product_region" = 'eu-central-1')) 
	OR (month_13."product_region" = 'ca-central-1')) 
	OR (month_13."product_region" = 'us-gov-west-1')) 
	OR (month_13."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_13."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)) mth13_ec2_sustainability_points

-- Key Metric: Instance Cost
,(CASE
	WHEN (("sum"(TRY_CAST(month_13."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_13."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_13."line_item_unblended_cost" AS decimal(16,8))))
	END) mth13_instance_cost

-- Key Metric: Cost per Sustainability Point
,(((CASE
	WHEN (("sum"(TRY_CAST(month_13."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_13."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_13."line_item_unblended_cost" AS decimal(16,8))))
	END))/((((TRY_CAST(month_13."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_13."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_13."product_region" = 'eu-west-1') 
	OR (month_13."product_region" = 'eu-central-1')) 
	OR (month_13."product_region" = 'ca-central-1')) 
	OR (month_13."product_region" = 'us-gov-west-1')) 
	OR (month_13."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_13."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)))) mth13_Cost_per_Sus_Point


FROM
  "customer_all" month_13

WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '13' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '13' MONTH))) 
	AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '12' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '12' MONTH))))

AND
	(((((month_13."line_item_product_code" = 'AmazonEC2') 
	AND (month_13."product_servicecode" <> 'AWSDataTransfer')) 
	AND (month_13."line_item_operation" LIKE '%RunInstances%')) 
	AND (NOT (month_13."line_item_usage_type" LIKE '%DataXfer%'))) 
	AND (((month_13."line_item_line_item_type" = 'Usage') 
	OR (month_13."line_item_line_item_type" = 'SavingsPlanCoveredUsage')) 
	OR (month_13."line_item_line_item_type" = 'DiscountedUsage')))

GROUP BY "bill_payer_account_id"
	, "line_item_usage_account_id"
	, "line_item_product_code"
	, "product_region"
	, "product_servicecode"
	, "line_item_operation"
	, "line_item_usage_type"
	, "line_item_line_item_type"
	, "pricing_term"
	, "product_clock_speed"
	, "product_instance_family"
	, "product_instance_type"
	, "product_instance_type_family"
	, "product_vcpu"
	, "year"
	, "month"
	, "line_item_resource_id"
-- end of create view