-- Create a view for the third prior month
CREATE OR REPLACE VIEW "view_month_03" AS 
SELECT DISTINCT
  month_3."bill_payer_account_id" mth3_bill_payer_account_id
  , month_3."line_item_usage_account_id" mth3_linked_acct_id
  , month_3."line_item_product_code" mth3_prod_code
  , month_3."line_item_resource_id" mth3_resource_id
  , month_3."line_item_line_item_description" mth3_description
  , month_3."line_item_line_item_type" mth3_charge_type
  , month_3."line_item_operation" mth3_operation
  , month_3."line_item_unblended_rate" mth3_unblended_rate
  , month_3."product_instance_type" mth3_instance
  , month_3."product_product_family" mth3_prod_family
  , month_3."product_instance_family" mth3_instance_family
  , month_3."product_instance_type" mth3_instance_type
  , month_3."product_instance_type_family" mth3_instance_type_family
  , month_3."product_tenancy" mth3_tenancy
  , month_3."product_location" mth3_region
  , month_3."product_location_type" mth3_location_type
  , month_3."product_operating_system" mth3_operating_system
--  , month_3."savings_plan_region" mth3_sp_region
--  , month_3."savings_plan_purchase_term" mth3_term_length
--  , month_3."savings_plan_payment_option" mth3_payment_options
--  , month_3."savings_plan_offering_type" mth3_sp_type
  , month_3."savings_plan_savings_plan_a_r_n" mth3_sp_arn
  , month_3."savings_plan_savings_plan_rate" mth3_sp_rate
  , month_3."product_volume_type" mth3_storage_class
  , "sum"(TRY_CAST(month_3."line_item_unblended_cost" AS decimal(16,8))) month_3_cost
  , "sum"(TRY_CAST(month_3."line_item_usage_amount" AS decimal(16,8))) month_3_usage
  , month_3."year" mth3_year
  , month_3."month" mth3_month
  , month_3."bill_payer_account_id" mth3_payer
FROM
  "customer_all" month_3
WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '3' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '3' MONTH))) AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '2' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '2' MONTH))))
GROUP BY "bill_payer_account_id"
  , "line_item_usage_account_id"
  , "line_item_product_code"
  , "line_item_resource_id"
  , "line_item_line_item_description"
  , "line_item_line_item_type"
  , "line_item_operation"
  , "line_item_unblended_rate"
  , "product_instance_type"
  , "product_product_family"
  , "savings_plan_savings_plan_a_r_n"
  , "savings_plan_savings_plan_rate"
  , "product_volume_type"
  , "year"
  , "month"
  , "product_instance_type_family"
  , "product_tenancy"
  , "product_location"
  , "product_location_type"
  , "product_operating_system"
--  , "savings_plan_region"
--  , "savings_plan_purchase_term"
--  , "savings_plan_payment_option"
--  , "savings_plan_offering_type"
  , "product_instance_family"
  , "product_instance_type"
-- end of create view