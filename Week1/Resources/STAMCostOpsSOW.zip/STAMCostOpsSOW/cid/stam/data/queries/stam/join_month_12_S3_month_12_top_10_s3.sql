-- Create a S3 storage view for the join_month_12_S3_month_12_top_10_s3
CREATE OR REPLACE VIEW "join_month_12_S3_month_12_top_10_s3" AS 
SELECT DISTINCT
  view_12.bill_payer_account_id
, view_12.linked_acct_id
, view_12.prod_code
, view_12.region
, view_12.description
, view_12.unblended_rate
, view_12.storage_class
, view_12.servicecode
, view_12.operation
, view_12.usage_type
, view_12.charge_type
, view_12.year
, view_12.month
, view_12.period
, view_12.mth_order
, view_12.bucket_id
, view_12.usage
, view_12.bucket_cost
, view_12_top_10.line_item_usage_account_id
FROM
  (view_s3_month_12 view_12
INNER JOIN view_s3_month_12_top_10_accts view_12_top_10 ON (view_12.linked_acct_id = view_12_top_10.line_item_usage_account_id))

-- end of create view