-- Create a S3 storage view for the join_month_10_S3_month_10_top_10_s3
CREATE OR REPLACE VIEW "join_month_10_S3_month_10_top_10_s3" AS 
SELECT DISTINCT
  view_10.bill_payer_account_id
, view_10.linked_acct_id
, view_10.prod_code
, view_10.region
, view_10.description
, view_10.unblended_rate
, view_10.storage_class
, view_10.servicecode
, view_10.operation
, view_10.usage_type
, view_10.charge_type
, view_10.year
, view_10.month
, view_10.period
, view_10.mth_order
, view_10.bucket_id
, view_10.usage
, view_10.bucket_cost
, view_10_top_10.line_item_usage_account_id
FROM
  (view_s3_month_10 view_10
INNER JOIN view_s3_month_10_top_10_accts view_10_top_10 ON (view_10.linked_acct_id = view_10_top_10.line_item_usage_account_id))

-- end of create view