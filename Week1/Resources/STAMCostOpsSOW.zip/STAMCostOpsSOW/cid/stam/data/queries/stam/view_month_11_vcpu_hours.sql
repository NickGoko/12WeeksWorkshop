-- Create a sustainability view for the 11th prior month
CREATE OR REPLACE VIEW "view_month_11_vcpu_hours" AS 
SELECT
  month_11."bill_payer_account_id" mth11_bill_payer_account_id
, month_11."line_item_usage_account_id" mth11_linked_acct_id
, month_11."line_item_product_code" mth11_prod_code
, month_11."product_region" mth11_region
, month_11."product_servicecode" mth11_servicecode
, month_11."line_item_operation" mth11_operation
, month_11."line_item_usage_type" mth11_usage_type
, month_11."line_item_line_item_type" mth11_charge_type
, month_11."pricing_term" mth11_pricing_term
, month_11."product_clock_speed" mth11_clock_speed
, month_11."product_instance_family" mth11_inst_family
, month_11."product_instance_type" mth11_instance
, month_11."product_instance_type_family" mth11_instance_type_family
, TRY_CAST(month_11."product_vcpu" AS int) mth11_vcpu_count
, month_11."year" mth11_year
, month_11."month" mth11_month
, month_11."line_item_resource_id" mth11_instance_id
, "split_part"(month_11."product_instance_type", '.', 1) mth11_instance_family
, (CASE 
	WHEN (((((month_11."product_region" = 'eu-west-1') 
	OR (month_11."product_region" = 'eu-central-1')) 
	OR (month_11."product_region" = 'ca-central-1')) 
	OR (month_11."product_region" = 'us-gov-west-1')) 
	OR (month_11."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END) mth11_r_points
, (CASE 
	WHEN ("split_part"(month_11."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END) mth11_instance_points
, "sum"(TRY_CAST(month_11."line_item_usage_amount" AS decimal(16,8))) mth11_instance_hours
, "sum"(TRY_CAST(month_11."line_item_unblended_cost" AS decimal(16,8))) mth11_od_instance_cost
, "sum"(TRY_CAST(month_11."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) mth11_sp_instance_cost

-- Calculate key metrics for sustainability

-- Key Metric: vcpu hours
, (TRY_CAST("product_vcpu" AS int)
	*("sum"(TRY_CAST(month_11."line_item_usage_amount" AS decimal(16,8))))) mth11_vcpu_hours

-- Key Metric: spot vcpu hours
,(CASE 
	WHEN (month_11."pricing_term" = '')
	THEN (TRY_CAST(month_11."product_vcpu" AS int)*("sum"(TRY_CAST(month_11."line_item_usage_amount" AS decimal(16,8)))))
	ELSE 0
	END) mth11_spot_vcpu_hours

-- Key Metric: EC2 Sustainability Points
, (((TRY_CAST("product_vcpu" AS int)
	*("sum"(TRY_CAST(month_11."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_11."product_region" = 'eu-west-1') 
	OR (month_11."product_region" = 'eu-central-1')) 
	OR (month_11."product_region" = 'ca-central-1')) 
	OR (month_11."product_region" = 'us-gov-west-1')) 
	OR (month_11."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_11."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)) mth11_ec2_sustainability_points

-- Key Metric: Instance Cost
,(CASE
	WHEN (("sum"(TRY_CAST(month_11."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_11."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_11."line_item_unblended_cost" AS decimal(16,8))))
	END) mth11_instance_cost

-- Key Metric: Cost per Sustainability Point
,(((CASE
	WHEN (("sum"(TRY_CAST(month_11."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_11."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_11."line_item_unblended_cost" AS decimal(16,8))))
	END))/((((TRY_CAST(month_11."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_11."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_11."product_region" = 'eu-west-1') 
	OR (month_11."product_region" = 'eu-central-1')) 
	OR (month_11."product_region" = 'ca-central-1')) 
	OR (month_11."product_region" = 'us-gov-west-1')) 
	OR (month_11."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_11."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)))) mth11_Cost_per_Sus_Point

FROM
  customer_all month_11

WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '11' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '11' MONTH))) 
	AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '10' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '10' MONTH))))

AND
	(((((month_11."line_item_product_code" = 'AmazonEC2') 
	AND (month_11."product_servicecode" <> 'AWSDataTransfer')) 
	AND (month_11."line_item_operation" LIKE '%RunInstances%')) 
	AND (NOT (month_11."line_item_usage_type" LIKE '%DataXfer%'))) 
	AND (((month_11."line_item_line_item_type" = 'Usage') 
	OR (month_11."line_item_line_item_type" = 'SavingsPlanCoveredUsage')) 
	OR (month_11."line_item_line_item_type" = 'DiscountedUsage')))

GROUP BY "bill_payer_account_id"
	, "line_item_usage_account_id"
	, "line_item_product_code"
	, "product_region"
	, "product_servicecode"
	, "line_item_operation"
	, "line_item_usage_type"
	, "line_item_line_item_type"
	, "pricing_term"
	, "product_clock_speed"
	, "product_instance_family"
	, "product_instance_type"
	, "product_instance_type_family"
	, "product_vcpu"
	, "year"
	, "month"
	, "line_item_resource_id"
-- end of create view