-- Create a S3 storage view for the view_s3_month_02
CREATE OR REPLACE VIEW "view_s3_month_02" AS 
SELECT DISTINCT
  "bill_payer_account_id" bill_payer_account_id
, DATE_FORMAT(("line_item_usage_start_date"),'%Y-%m-%d') AS day_line_item_usage_start_date
, "year" year
, "month" month
, "line_item_usage_account_id" linked_acct_id
, "line_item_product_code" prod_code
, "product_region" region
, "line_item_line_item_description" description
, "line_item_unblended_rate" unblended_rate
, "product_volume_type" storage_class
, "product_servicecode" servicecode
, "line_item_operation" operation
, "line_item_usage_type" usage_type
, "line_item_line_item_type" charge_type

, (CASE WHEN ((TRY_CAST(month AS integer) < 10) AND ("substring"(month, 1, 1) <> '0')) 
    THEN "concat"(year, ' - ', '0', month) ELSE "concat"(year, ' - ', month) END) period

, (CASE WHEN ((TRY_CAST(month AS integer) < 10) AND ("substring"(month, 1, 1) <> '0')) 
    THEN "concat"('0', month) ELSE month END) mth_order

, "line_item_resource_id" bucket_id
, "sum"(TRY_CAST("line_item_usage_amount" AS decimal(16,8))) usage
, "sum"(TRY_CAST("line_item_unblended_cost" AS decimal(16,8))) bucket_cost
FROM
  "${cur_table_name}"

WHERE (((("line_item_product_code" LIKE '%S3%') AND ("line_item_resource_id" <> '')) AND (NOT (product_volume_type LIKE 'Tags')))
  AND  ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '2' MONTH)) 
  AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '2' MONTH))) 
  AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '1' MONTH)) 
  AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '1' MONTH)))))

GROUP BY "bill_payer_account_id"
    , "line_item_usage_account_id"
    , "line_item_product_code"
    , "product_region"
    , "line_item_line_item_description"
    , "line_item_unblended_rate"
    , "product_volume_type"
    , "product_servicecode"
    , "line_item_operation"
    , "line_item_usage_type"
    , "line_item_line_item_type"
    , "year"
    , "month"
    , "line_item_resource_id"
    , "line_item_usage_start_date"

ORDER BY bucket_cost DESC

-- end of create view