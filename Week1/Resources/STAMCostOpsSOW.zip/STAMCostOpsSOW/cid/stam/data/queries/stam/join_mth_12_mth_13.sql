-- Create a view for join_mth_12_mth_13
CREATE OR REPLACE VIEW "join_mth_12_mth_13" AS 
SELECT
-- Select from view_month_12
  view_month_12."mth12_bill_payer_account_id"
, view_month_12."mth12_linked_acct_id"
, view_month_12."mth12_prod_code"
, view_month_12."mth12_resource_id"
, view_month_12."mth12_description"
, view_month_12."mth12_charge_type"
, view_month_12."mth12_operation"
, view_month_12."mth12_unblended_rate"
, view_month_12."mth12_instance"
, view_month_12."mth12_prod_family"
, view_month_12."mth12_instance_family"
, view_month_12."mth12_instance_type"
, view_month_12."mth12_instance_type_family"
, view_month_12."mth12_tenancy"
, view_month_12."mth12_region"
, view_month_12."mth12_location_type"
, view_month_12."mth12_operating_system"
--, view_month_12."mth12_sp_region"
--, view_month_12."mth12_term_length"
--, view_month_12."mth12_payment_options"
--, view_month_12."mth12_sp_type"
, view_month_12."mth12_sp_arn"
, view_month_12."mth12_sp_rate"
, view_month_12."mth12_storage_class"
, view_month_12."mth12_year"
, view_month_12."mth12_month"
, view_month_12."mth12_payer"
-- Select from view_month_13
, view_month_13."mth13_bill_payer_account_id"
, view_month_13."mth13_linked_acct_id"
, view_month_13."mth13_prod_code"
, view_month_13."mth13_resource_id"
, view_month_13."mth13_description"
, view_month_13."mth13_charge_type"
, view_month_13."mth13_operation"
, view_month_13."mth13_unblended_rate"
, view_month_13."mth13_instance"
, view_month_13."mth13_prod_family"
, view_month_13."mth13_instance_family"
, view_month_13."mth13_instance_type"
, view_month_13."mth13_instance_type_family"
, view_month_13."mth13_tenancy"
, view_month_13."mth13_region"
, view_month_13."mth13_location_type"
, view_month_13."mth13_operating_system"
--, view_month_13."mth13_sp_region"
--, view_month_13."mth13_term_length"
--, view_month_13."mth13_payment_options"
--, view_month_13."mth13_sp_type"
, view_month_13."mth13_sp_arn"
, view_month_13."mth13_sp_rate"
, view_month_13."mth13_storage_class"
, view_month_13."mth13_year"
, view_month_13."mth13_month"
, view_month_13."mth13_payer"

-- update 14-Jan-23: fix filters on control plane
, (CASE WHEN (TRY_CAST(view_month_12."mth12_bill_payer_account_id" AS VARCHAR) IS NULL) THEN view_month_13."mth13_bill_payer_account_id" ELSE view_month_12."mth12_bill_payer_account_id" END) join_12_13_payer
, (CASE WHEN (TRY_CAST(view_month_12."mth12_linked_acct_id" AS VARCHAR) IS NULL) THEN view_month_13."mth13_linked_acct_id" ELSE view_month_12."mth12_linked_acct_id" END) join_12_13_linked_acct_id
, (CASE WHEN (TRY_CAST(view_month_12."mth12_prod_code" AS VARCHAR) IS NULL) THEN view_month_13."mth13_prod_code" ELSE view_month_12."mth12_prod_code" END) join_12_13_prod_code
, (CASE WHEN (TRY_CAST(view_month_12."mth12_resource_id" AS VARCHAR) IS NULL) THEN view_month_13."mth13_resource_id" ELSE view_month_12."mth12_resource_id" END) join_12_13_resource_id
, (CASE WHEN (TRY_CAST(view_month_12."mth12_charge_type" AS VARCHAR) IS NULL) THEN view_month_13."mth13_charge_type" ELSE view_month_12."mth12_charge_type" END) join_12_13_charge_type
, (CASE WHEN (TRY_CAST(view_month_12."mth12_operation" AS VARCHAR) IS NULL) THEN view_month_13."mth13_operation" ELSE view_month_12."mth12_operation" END) join_12_13_operation
, (CASE WHEN (TRY_CAST(view_month_12."mth12_prod_family" AS VARCHAR) IS NULL) THEN view_month_13."mth13_prod_family" ELSE view_month_12."mth12_prod_family" END) join_12_13_prod_family
, (CASE WHEN (TRY_CAST(view_month_12."mth12_instance_family" AS VARCHAR) IS NULL) THEN view_month_13."mth13_instance_family" ELSE view_month_12."mth12_instance_family" END) join_12_13_inst_family
, (CASE WHEN (TRY_CAST(view_month_12."mth12_instance_type" AS VARCHAR) IS NULL) THEN view_month_13."mth13_instance_type" ELSE view_month_12."mth12_instance_type" END) join_12_13_inst_type
, (CASE WHEN (TRY_CAST(view_month_12."mth12_tenancy" AS VARCHAR) IS NULL) THEN view_month_13."mth13_tenancy" ELSE view_month_12."mth12_tenancy" END) join_12_13_tenancy
, (CASE WHEN (TRY_CAST(view_month_12."mth12_region" AS VARCHAR) IS NULL) THEN view_month_13."mth13_region" ELSE view_month_12."mth12_region" END) join_12_13_region
, (CASE WHEN (TRY_CAST(view_month_12."mth12_operating_system" AS VARCHAR) IS NULL) THEN view_month_13."mth13_operating_system" ELSE view_month_12."mth12_operating_system" END) join_12_13_op_system
, (CASE WHEN (TRY_CAST(view_month_12."mth12_sp_arn" AS VARCHAR) IS NULL) THEN view_month_13."mth13_sp_arn" ELSE view_month_12."mth12_sp_arn" END) join_12_13_sp_arn
, (CASE WHEN (TRY_CAST(view_month_12."mth12_storage_class" AS VARCHAR) IS NULL) THEN view_month_13."mth13_storage_class" ELSE view_month_12."mth12_storage_class" END) join_12_13_storage_class

-- end update 14-Jan-23

, TRY_CAST(view_month_12."month_12_cost" AS decimal(16,8)) cur_mth_cost
, TRY_CAST(view_month_12."month_12_usage" AS decimal(16,8)) cur_mth_usg

, TRY_CAST(view_month_13."month_13_cost" AS decimal(16,8)) prev_mth_cost
, TRY_CAST(view_month_13."month_13_usage" AS decimal(16,8)) prev_mth_usg

, (TRY_CAST(view_month_12."month_12_cost" AS decimal(16,8)) - TRY_CAST(view_month_13."month_13_cost" AS decimal(16,8))) cost_var
, (TRY_CAST(view_month_12."month_12_usage" AS decimal(16,8)) - TRY_CAST(view_month_13."month_13_usage" AS decimal(16,8))) usg_var

, (CASE WHEN ((TRY_CAST(view_month_12."month_12_cost" AS decimal(16,8)) - TRY_CAST(view_month_13."month_13_cost" AS decimal(16,8))) < 0) 
THEN "abs"(TRY_CAST((TRY_CAST(view_month_12."month_12_cost" AS decimal(16,8)) - TRY_CAST(view_month_13."month_13_cost" AS decimal(16,8))) AS decimal(16,8))) 
ELSE 0E0 END) savings
, (CASE WHEN ((TRY_CAST(view_month_12."month_12_cost" AS decimal(16,8)) - TRY_CAST(view_month_13."month_13_cost" AS decimal(16,8))) > 0) 
THEN TRY_CAST((TRY_CAST(view_month_12."month_12_cost" AS decimal(16,8)) - TRY_CAST(view_month_13."month_13_cost" AS decimal(16,8))) AS decimal(16,8)) 
ELSE 0E0 END) inc_cost

FROM
 customer_cur_data."view_month_12"

FULL JOIN view_month_13 ON (((((((((((((((((((((view_month_12."mth12_bill_payer_account_id" = view_month_13."mth13_bill_payer_account_id") 
  AND (view_month_12."mth12_linked_acct_id" = view_month_13."mth13_linked_acct_id")) 
  AND (view_month_12."mth12_prod_code" = view_month_13."mth13_prod_code")) 
  AND (view_month_12."mth12_resource_id" = view_month_13."mth13_resource_id")) 
  AND (view_month_12."mth12_description" = view_month_13."mth13_description")) 
  AND (view_month_12."mth12_charge_type" = view_month_13."mth13_charge_type")) 
  AND (view_month_12."mth12_operation" = view_month_13."mth13_operation")) 
  AND (view_month_12."mth12_unblended_rate" = view_month_13."mth13_unblended_rate")) 
  AND (view_month_12."mth12_instance" = view_month_13."mth13_instance")) 
  AND (view_month_12."mth12_prod_family" = view_month_13."mth13_prod_family")) 
  AND (view_month_12."mth12_instance_family" = view_month_13."mth13_instance_family")) 
  AND (view_month_12."mth12_instance_type" = view_month_13."mth13_instance_type")) 
  AND (view_month_12."mth12_instance_type_family" = view_month_13."mth13_instance_type_family")) 
  AND (view_month_12."mth12_tenancy" = view_month_13."mth13_tenancy")) 
  AND (view_month_12."mth12_region" = view_month_13."mth13_region")) 
  AND (view_month_12."mth12_location_type" = view_month_13."mth13_location_type")) 
  AND (view_month_12."mth12_operating_system" = view_month_13."mth13_operating_system")) 
  --AND (view_month_12."mth12_sp_region" = view_month_13."mth13_sp_region")) 
  --AND (view_month_12."mth12_term_length" = view_month_13."mth13_term_length")) 
  --AND (view_month_12."mth12_payment_options" = view_month_13."mth13_payment_options")) 
  --AND (view_month_12."mth12_sp_type" = view_month_13."mth13_sp_type")) 
  AND (view_month_12."mth12_sp_arn" = view_month_13."mth13_sp_arn")) 
  AND (view_month_12."mth12_sp_rate" = view_month_13."mth13_sp_rate")) 
  AND (view_month_12."mth12_storage_class" = view_month_13."mth13_storage_class")) 
  AND (view_month_12."mth12_payer" = view_month_13."mth13_payer"))

GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52
, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66
-- end of create view