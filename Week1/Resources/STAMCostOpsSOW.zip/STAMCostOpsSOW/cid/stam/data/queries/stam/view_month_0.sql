-- Create a view for the current month
CREATE OR REPLACE VIEW "view_month_0" AS 
SELECT DISTINCT
  month_0."bill_payer_account_id" mth0_bill_payer_account_id
  , month_0."line_item_usage_account_id" mth0_linked_acct_id
  , month_0."line_item_product_code" mth0_prod_code
  , month_0."line_item_resource_id" mth0_resource_id
  , month_0."line_item_line_item_description" mth0_description
  , month_0."line_item_line_item_type" mth0_charge_type
  , month_0."line_item_operation" mth0_operation
  , month_0."line_item_unblended_rate" mth0_unblended_rate
  , month_0."product_instance_type" mth0_instance
  , month_0."product_product_family" mth0_prod_family
  , month_0."product_instance_family" mth0_instance_family
  , month_0."product_instance_type" mth0_instance_type
  , month_0."product_instance_type_family" mth0_instance_type_family
  , month_0."product_tenancy" mth0_tenancy
  , month_0."product_location" mth0_region
  , month_0."product_location_type" mth0_location_type
  , month_0."product_operating_system" mth0_operating_system
  --, month_0."savings_plan_region" mth0_sp_region
  --, month_0."savings_plan_purchase_term" mth0_term_length
  --, month_0."savings_plan_payment_option" mth0_payment_options
  --, month_0."savings_plan_offering_type" mth0_sp_type
  , month_0."savings_plan_savings_plan_a_r_n" mth0_sp_arn
  , month_0."savings_plan_savings_plan_rate" mth0_sp_rate
  , month_0."product_volume_type" mth0_storage_class
  , "sum"(TRY_CAST(month_0."line_item_unblended_cost" AS decimal(16,8))) month_0_cost
  , "sum"(TRY_CAST(month_0."line_item_usage_amount" AS decimal(16,8))) month_0_usage
  , month_0."year" mth0_year
  , month_0."month" mth0_month
  , month_0."bill_payer_account_id" mth0_payer
FROM
  "customer_all" month_0
WHERE (("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '0' MONTH)) 
AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '0' MONTH)))
GROUP BY "bill_payer_account_id"
  , "line_item_usage_account_id"
  , "line_item_product_code"
  , "line_item_resource_id"
  , "line_item_line_item_description"
  , "line_item_line_item_type"
  , "line_item_operation"
  , "line_item_unblended_rate"
  , "product_instance_type"
  , "product_product_family"
  , "savings_plan_savings_plan_a_r_n"
  , "savings_plan_savings_plan_rate"
  , "product_volume_type"
  , "year"
  , "month"
  , "product_instance_type_family"
  , "product_tenancy"
  , "product_location"
  , "product_location_type"
  , "product_operating_system"
  --, "savings_plan_region"
  --, "savings_plan_purchase_term"
  --, "savings_plan_payment_option"
  --, "savings_plan_offering_type"
  , "product_instance_family"
  , "product_instance_type"
-- end of create view