-- Create a sustainability view for the 2nd prior month
CREATE OR REPLACE VIEW "view_month_02_vcpu_hours" AS 
SELECT
  month_2."bill_payer_account_id" mth2_bill_payer_account_id
, month_2."line_item_usage_account_id" mth2_linked_acct_id
, month_2."line_item_product_code" mth2_prod_code
, month_2."product_region" mth2_region
, month_2."product_servicecode" mth2_servicecode
, month_2."line_item_operation" mth2_operation
, month_2."line_item_usage_type" mth2_usage_type
, month_2."line_item_line_item_type" mth2_charge_type
, month_2."pricing_term" mth2_pricing_term
, month_2."product_clock_speed" mth2_clock_speed
, month_2."product_instance_family" mth2_inst_family
, month_2."product_instance_type" mth2_instance
, month_2."product_instance_type_family" mth2_instance_type_family
, TRY_CAST(month_2."product_vcpu" AS int)  mth2_vcpu_count
, month_2."year" mth2_year
, month_2."month" mth2_month

, month_2."line_item_resource_id" mth2_instance_id
, "split_part"(month_2."product_instance_type", '.', 1) mth2_instance_family
, (CASE 
	WHEN (((((month_2."product_region" = 'eu-west-1') 
	OR (month_2."product_region" = 'eu-central-1')) 
	OR (month_2."product_region" = 'ca-central-1')) 
	OR (month_2."product_region" = 'us-gov-west-1')) 
	OR (month_2."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END) mth2_r_points
, (CASE 
	WHEN ("split_part"(month_2."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END) mth2_instance_points
, "sum"(TRY_CAST(month_2."line_item_usage_amount" AS decimal(16,8))) mth2_instance_hours
, "sum"(TRY_CAST(month_2."line_item_unblended_cost" AS decimal(16,8))) mth2_od_instance_cost
, "sum"(TRY_CAST(month_2."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) mth2_sp_instance_cost


-- Calculate key metrics for sustainability

-- Key Metric: vcpu hours
, (TRY_CAST(month_2."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_2."line_item_usage_amount" AS decimal(16,8))))) mth2_vcpu_hours

-- Key Metric: spot vcpu hours
,(CASE 
	WHEN (month_2."pricing_term" = '')
	THEN (TRY_CAST(month_2."product_vcpu" AS int)*("sum"(TRY_CAST(month_2."line_item_usage_amount" AS decimal(16,8)))))
	ELSE 0
	END) mth2_spot_vcpu_hours

-- Key Metric: EC2 Sustainability Points
, (((TRY_CAST(month_2."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_2."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_2."product_region" = 'eu-west-1') 
	OR (month_2."product_region" = 'eu-central-1')) 
	OR (month_2."product_region" = 'ca-central-1')) 
	OR (month_2."product_region" = 'us-gov-west-1')) 
	OR (month_2."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_2."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)) mth2_ec2_sustainability_points

-- Key Metric: Instance Cost
,(CASE
	WHEN (("sum"(TRY_CAST(month_2."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_2."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_2."line_item_unblended_cost" AS decimal(16,8))))
	END) mth2_instance_cost

-- Key Metric: Cost per Sustainability Point
,(((CASE
	WHEN (("sum"(TRY_CAST(month_2."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_2."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_2."line_item_unblended_cost" AS decimal(16,8))))
	END))/((((TRY_CAST(month_2."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_2."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_2."product_region" = 'eu-west-1') 
	OR (month_2."product_region" = 'eu-central-1')) 
	OR (month_2."product_region" = 'ca-central-1')) 
	OR (month_2."product_region" = 'us-gov-west-1')) 
	OR (month_2."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_2."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)))) mth2_Cost_per_Sus_Point

FROM
  "customer_all" month_2

WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '2' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '2' MONTH))) 
	AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '1' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '1' MONTH))))
AND
	(((((month_2."line_item_product_code" = 'AmazonEC2') 
	AND (month_2."product_servicecode" <> 'AWSDataTransfer')) 
	AND (month_2."line_item_operation" LIKE '%RunInstances%')) 
	AND (NOT (month_2."line_item_usage_type" LIKE '%DataXfer%'))) 
	AND (((month_2."line_item_line_item_type" = 'Usage') 
	OR (month_2."line_item_line_item_type" = 'SavingsPlanCoveredUsage')) 
	OR (month_2."line_item_line_item_type" = 'DiscountedUsage')))

GROUP BY "bill_payer_account_id"
	, "line_item_usage_account_id"
	, "line_item_product_code"
	, "product_region"
	, "product_servicecode"
	, "line_item_operation"
	, "line_item_usage_type"
	, "line_item_line_item_type"
	, "pricing_term"
	, "product_clock_speed"
	, "product_instance_family"
	, "product_instance_type"
	, "product_instance_type_family"
	, "product_vcpu"
	, "year"
	, "month"
	, "line_item_resource_id"
-- end of create view