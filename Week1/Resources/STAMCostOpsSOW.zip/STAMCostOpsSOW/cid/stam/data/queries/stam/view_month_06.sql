-- Create a view for the 6th prior month
CREATE OR REPLACE VIEW "view_month_06" AS 
SELECT DISTINCT
  month_6."bill_payer_account_id" mth6_bill_payer_account_id
  , month_6."line_item_usage_account_id" mth6_linked_acct_id
  , month_6."line_item_product_code" mth6_prod_code
  , month_6."line_item_resource_id" mth6_resource_id
  , month_6."line_item_line_item_description" mth6_description
  , month_6."line_item_line_item_type" mth6_charge_type
  , month_6."line_item_operation" mth6_operation
  , month_6."line_item_unblended_rate" mth6_unblended_rate
  , month_6."product_instance_type" mth6_instance
  , month_6."product_product_family" mth6_prod_family
  , month_6."product_instance_family" mth6_instance_family
  , month_6."product_instance_type" mth6_instance_type
  , month_6."product_instance_type_family" mth6_instance_type_family
  , month_6."product_tenancy" mth6_tenancy
  , month_6."product_location" mth6_region
  , month_6."product_location_type" mth6_location_type
  , month_6."product_operating_system" mth6_operating_system
--  , month_6."savings_plan_region" mth6_sp_region
--  , month_6."savings_plan_purchase_term" mth6_term_length
--  , month_6."savings_plan_payment_option" mth6_payment_options
--  , month_6."savings_plan_offering_type" mth6_sp_type
  , month_6."savings_plan_savings_plan_a_r_n" mth6_sp_arn
  , month_6."savings_plan_savings_plan_rate" mth6_sp_rate
  , month_6."product_volume_type" mth6_storage_class
  , "sum"(TRY_CAST(month_6."line_item_unblended_cost" AS decimal(16,8))) month_6_cost
  , "sum"(TRY_CAST(month_6."line_item_usage_amount" AS decimal(16,8))) month_6_usage
  , month_6."year" mth6_year
  , month_6."month" mth6_month
  , month_6."bill_payer_account_id" mth6_payer
FROM
  "customer_all" month_6
WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '6' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '6' MONTH))) AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '5' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '5' MONTH))))
GROUP BY "bill_payer_account_id"
  , "line_item_usage_account_id"
  , "line_item_product_code"
  , "line_item_resource_id"
  , "line_item_line_item_description"
  , "line_item_line_item_type"
  , "line_item_operation"
  , "line_item_unblended_rate"
  , "product_instance_type"
  , "product_product_family"
  , "savings_plan_savings_plan_a_r_n"
  , "savings_plan_savings_plan_rate"
  , "product_volume_type"
  , "year"
  , "month"
  , "product_instance_type_family"
  , "product_tenancy"
  , "product_location"
  , "product_location_type"
  , "product_operating_system"
--  , "savings_plan_region"
--  , "savings_plan_purchase_term"
--  , "savings_plan_payment_option"
--  , "savings_plan_offering_type"
  , "product_instance_family"
  , "product_instance_type"
-- end of create view