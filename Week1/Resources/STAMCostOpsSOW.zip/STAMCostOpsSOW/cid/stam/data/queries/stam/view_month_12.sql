-- Create a view for the 12th prior month
CREATE OR REPLACE VIEW "view_month_12" AS 
SELECT DISTINCT
  month_12."bill_payer_account_id" mth12_bill_payer_account_id
  , month_12."line_item_usage_account_id" mth12_linked_acct_id
  , month_12."line_item_product_code" mth12_prod_code
  , month_12."line_item_resource_id" mth12_resource_id
  , month_12."line_item_line_item_description" mth12_description
  , month_12."line_item_line_item_type" mth12_charge_type
  , month_12."line_item_operation" mth12_operation
  , month_12."line_item_unblended_rate" mth12_unblended_rate
  , month_12."product_instance_type" mth12_instance
  , month_12."product_product_family" mth12_prod_family
  , month_12."product_instance_family" mth12_instance_family
  , month_12."product_instance_type" mth12_instance_type
  , month_12."product_instance_type_family" mth12_instance_type_family
  , month_12."product_tenancy" mth12_tenancy
  , month_12."product_location" mth12_region
  , month_12."product_location_type" mth12_location_type
  , month_12."product_operating_system" mth12_operating_system
--  , month_12."savings_plan_region" mth12_sp_region
--  , month_12."savings_plan_purchase_term" mth12_term_length
--  , month_12."savings_plan_payment_option" mth12_payment_options
--  , month_12."savings_plan_offering_type" mth12_sp_type
  , month_12."savings_plan_savings_plan_a_r_n" mth12_sp_arn
  , month_12."savings_plan_savings_plan_rate" mth12_sp_rate
  , month_12."product_volume_type" mth12_storage_class
  , "sum"(TRY_CAST(month_12."line_item_unblended_cost" AS decimal(16,8))) month_12_cost
  , "sum"(TRY_CAST(month_12."line_item_usage_amount" AS decimal(16,8))) month_12_usage
  , month_12."year" mth12_year
  , month_12."month" mth12_month
  , month_12."bill_payer_account_id" mth12_payer
FROM
  "customer_all" month_12
WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '12' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '12' MONTH))) AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '11' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '11' MONTH))))
GROUP BY "bill_payer_account_id"
  , "line_item_usage_account_id"
  , "line_item_product_code"
  , "line_item_resource_id"
  , "line_item_line_item_description"
  , "line_item_line_item_type"
  , "line_item_operation"
  , "line_item_unblended_rate"
  , "product_instance_type"
  , "product_product_family"
  , "savings_plan_savings_plan_a_r_n"
  , "savings_plan_savings_plan_rate"
  , "product_volume_type"
  , "year"
  , "month"
  , "product_instance_type_family"
  , "product_tenancy"
  , "product_location"
  , "product_location_type"
  , "product_operating_system"
--  , "savings_plan_region"
--  , "savings_plan_purchase_term"
--  , "savings_plan_payment_option"
--  , "savings_plan_offering_type"
  , "product_instance_family"
  , "product_instance_type"
-- end of create view