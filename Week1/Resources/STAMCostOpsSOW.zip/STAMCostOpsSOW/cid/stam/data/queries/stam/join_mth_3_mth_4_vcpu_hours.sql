-- Create a sustainability view for the join_mth_3_mth_4_vcpu_hours
CREATE OR REPLACE VIEW "join_mth_3_mth_4_vcpu_hours" AS 
SELECT
-- Select from view_month_03
  view_month_03_vcpu_hours."mth3_bill_payer_account_id"
, view_month_03_vcpu_hours."mth3_linked_acct_id"
, view_month_03_vcpu_hours."mth3_prod_code"
, view_month_03_vcpu_hours."mth3_region"
, view_month_03_vcpu_hours."mth3_servicecode"
, view_month_03_vcpu_hours."mth3_operation"
, view_month_03_vcpu_hours."mth3_usage_type"
, view_month_03_vcpu_hours."mth3_charge_type"
, view_month_03_vcpu_hours."mth3_pricing_term"
, view_month_03_vcpu_hours."mth3_clock_speed"
, view_month_03_vcpu_hours."mth3_inst_family"
, view_month_03_vcpu_hours."mth3_instance"
, view_month_03_vcpu_hours."mth3_instance_type_family"
, view_month_03_vcpu_hours."mth3_vcpu_count"
, view_month_03_vcpu_hours."mth3_year"
, view_month_03_vcpu_hours."mth3_month"
, view_month_03_vcpu_hours."mth3_instance_id"
, view_month_03_vcpu_hours."mth3_instance_family"
, view_month_03_vcpu_hours."mth3_r_points"
, view_month_03_vcpu_hours."mth3_instance_points"
-- Select from view_month_04
, view_month_04_vcpu_hours."mth4_bill_payer_account_id"
, view_month_04_vcpu_hours."mth4_linked_acct_id"
, view_month_04_vcpu_hours."mth4_prod_code"
, view_month_04_vcpu_hours."mth4_region"
, view_month_04_vcpu_hours."mth4_servicecode"
, view_month_04_vcpu_hours."mth4_operation"
, view_month_04_vcpu_hours."mth4_usage_type"
, view_month_04_vcpu_hours."mth4_charge_type"
, view_month_04_vcpu_hours."mth4_pricing_term"
, view_month_04_vcpu_hours."mth4_clock_speed"
, view_month_04_vcpu_hours."mth4_inst_family"
, view_month_04_vcpu_hours."mth4_instance"
, view_month_04_vcpu_hours."mth4_instance_type_family"
, view_month_04_vcpu_hours."mth4_vcpu_count"
, view_month_04_vcpu_hours."mth4_year"
, view_month_04_vcpu_hours."mth4_month"
, view_month_04_vcpu_hours."mth4_instance_id"
, view_month_04_vcpu_hours."mth4_instance_family"
, view_month_04_vcpu_hours."mth4_r_points"
, view_month_04_vcpu_hours."mth4_instance_points"

, TRY_CAST(view_month_03_vcpu_hours."mth3_instance_hours" AS decimal(16,8)) cur_mth_instance_hrs
, TRY_CAST(view_month_03_vcpu_hours."mth3_od_instance_cost" AS decimal(16,8)) cur_mth_od_cost
, TRY_CAST(view_month_03_vcpu_hours."mth3_sp_instance_cost" AS decimal(16,8)) cur_mth_sp_cost

, TRY_CAST(view_month_04_vcpu_hours."mth4_instance_hours" AS decimal(16,8)) prev_mth_instance_hrs
, TRY_CAST(view_month_04_vcpu_hours."mth4_od_instance_cost" AS decimal(16,8)) prev_mth_od_cost
, TRY_CAST(view_month_04_vcpu_hours."mth4_sp_instance_cost" AS decimal(16,8)) prev_mth_sp_cost

, (TRY_CAST(view_month_03_vcpu_hours."mth3_instance_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_instance_hours" AS decimal(16,8))) instance_hrs_var
, (TRY_CAST(view_month_03_vcpu_hours."mth3_od_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_od_instance_cost" AS decimal(16,8))) od_cost_var
, (TRY_CAST(view_month_03_vcpu_hours."mth3_sp_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_sp_instance_cost" AS decimal(16,8))) sp_cost_var

-- total metrics

, TRY_CAST(view_month_03_vcpu_hours."mth3_vcpu_hours" AS decimal(16,8)) cur_mth_vcpu_hours
, TRY_CAST(view_month_03_vcpu_hours."mth3_spot_vcpu_hours" AS decimal(16,8)) cur_mth_spot_vcpu_hours
, TRY_CAST(view_month_03_vcpu_hours."mth3_ec2_sustainability_points" AS decimal(16,8)) cur_mth_ec2_sustainability_points
, TRY_CAST(view_month_03_vcpu_hours."mth3_instance_cost" AS decimal(16,8)) cur_mth_instance_cost
, TRY_CAST(view_month_03_vcpu_hours."mth3_Cost_per_Sus_Point" AS decimal(16,8)) cur_mth_Cost_per_Sus_Point

, TRY_CAST(view_month_04_vcpu_hours."mth4_vcpu_hours" AS decimal(16,8)) prev_mth_vcpu_hours
, TRY_CAST(view_month_04_vcpu_hours."mth4_spot_vcpu_hours" AS decimal(16,8)) prev_mth_spot_vcpu_hours
, TRY_CAST(view_month_04_vcpu_hours."mth4_ec2_sustainability_points" AS decimal(16,8)) prev_mth_ec2_sustainability_points
, TRY_CAST(view_month_04_vcpu_hours."mth4_instance_cost" AS decimal(16,8)) prev_mth_instance_cost
, TRY_CAST(view_month_04_vcpu_hours."mth4_Cost_per_Sus_Point" AS decimal(16,8)) prev_mth_Cost_per_Sus_Point

-- end

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_od_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_od_instance_cost" AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_od_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_od_instance_cost" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) od_savings

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_od_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_od_instance_cost" AS decimal(16,8))) > 0) 
	THEN TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_od_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_od_instance_cost" AS decimal(16,8))) AS decimal(16,8)) 
	ELSE 0E0 
	END) od_inc_cost

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_sp_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_sp_instance_cost" AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_sp_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_sp_instance_cost" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) sp_savings

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_sp_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_sp_instance_cost" AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_sp_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_sp_instance_cost" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) sp_inc_cost

-- Calculate key metrics for sustainability


-- vcpu hours    
-- mth0_vcpu_hours
-- mth1_vcpu_hours

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_vcpu_hours" AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_vcpu_hours" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_vcpu_hours
, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_vcpu_hours" AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_vcpu_hours" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_vcpu_hours

-- spot vcpu hours    
-- mth0_spot_vcpu_hours
-- mth1_spot_vcpu_hours

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_spot_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_spot_vcpu_hours" AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_spot_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_spot_vcpu_hours" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_spot_vcpu_hours
, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_spot_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_spot_vcpu_hours" AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_spot_vcpu_hours" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_spot_vcpu_hours" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_spot_vcpu_hours

-- ec2 sustainability points    
-- mth0_ec2_sustainability_points
-- mth1_ec2_sustainability_points

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_ec2_sustainability_points" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_ec2_sustainability_points" AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_ec2_sustainability_points" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_ec2_sustainability_points" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_ec2_sustainability_points
, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_ec2_sustainability_points" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_ec2_sustainability_points" AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_ec2_sustainability_points" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_ec2_sustainability_points" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_ec2_sustainability_points

-- instance cost    
-- mth0_instance_cost
-- mth1_instance_cost

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_instance_cost" AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_instance_cost" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_instance_cost
, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_instance_cost" AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_instance_cost" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_instance_cost" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_instance_cost

-- cost per sustainability point    
-- mth0_Cost_per_Sus_Point
-- mth1_Cost_per_Sus_Point

, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_Cost_per_Sus_Point" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_Cost_per_Sus_Point" AS decimal(16,8))) > 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_Cost_per_Sus_Point" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_Cost_per_Sus_Point" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) inc_Cost_per_Sus_Point
, (CASE 
	WHEN ((TRY_CAST(view_month_03_vcpu_hours."mth3_Cost_per_Sus_Point" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_Cost_per_Sus_Point" AS decimal(16,8))) < 0) 
	THEN "abs"(TRY_CAST((TRY_CAST(view_month_03_vcpu_hours."mth3_Cost_per_Sus_Point" AS decimal(16,8)) - TRY_CAST(view_month_04_vcpu_hours."mth4_Cost_per_Sus_Point" AS decimal(16,8))) AS decimal(16,8))) 
	ELSE 0E0 
	END) savings_Cost_per_Sus_Point

-- end

FROM
 customer_cur_data."view_month_03_vcpu_hours"

FULL JOIN view_month_04_vcpu_hours ON ((((((((((((((((((view_month_03_vcpu_hours."mth3_bill_payer_account_id" = view_month_04_vcpu_hours."mth4_bill_payer_account_id") 
    AND (view_month_03_vcpu_hours."mth3_linked_acct_id" = view_month_04_vcpu_hours."mth4_linked_acct_id")) 
    AND (view_month_03_vcpu_hours."mth3_prod_code" = view_month_04_vcpu_hours."mth4_prod_code")) 
    AND (view_month_03_vcpu_hours."mth3_region" = view_month_04_vcpu_hours."mth4_region")) 
    AND (view_month_03_vcpu_hours."mth3_servicecode" = view_month_04_vcpu_hours."mth4_servicecode")) 
    AND (view_month_03_vcpu_hours."mth3_operation" = view_month_04_vcpu_hours."mth4_operation")) 
    AND (view_month_03_vcpu_hours."mth3_usage_type" = view_month_04_vcpu_hours."mth4_usage_type")) 
    AND (view_month_03_vcpu_hours."mth3_charge_type" = view_month_04_vcpu_hours."mth4_charge_type")) 
    AND (view_month_03_vcpu_hours."mth3_pricing_term" = view_month_04_vcpu_hours."mth4_pricing_term")) 
    AND (view_month_03_vcpu_hours."mth3_clock_speed" = view_month_04_vcpu_hours."mth4_clock_speed")) 
    AND (view_month_03_vcpu_hours."mth3_inst_family" = view_month_04_vcpu_hours."mth4_inst_family")) 
    AND (view_month_03_vcpu_hours."mth3_instance" = view_month_04_vcpu_hours."mth4_instance")) 
    AND (view_month_03_vcpu_hours."mth3_instance_type_family" = view_month_04_vcpu_hours."mth4_instance_type_family")) 
    AND (view_month_03_vcpu_hours."mth3_vcpu_count" = view_month_04_vcpu_hours."mth4_vcpu_count")) 
    AND (view_month_03_vcpu_hours."mth3_instance_id" = view_month_04_vcpu_hours."mth4_instance_id")) 
    AND (view_month_03_vcpu_hours."mth3_instance_family" = view_month_04_vcpu_hours."mth4_instance_family")) 
    AND (view_month_03_vcpu_hours."mth3_r_points" = view_month_04_vcpu_hours."mth4_r_points")) 
    AND (view_month_03_vcpu_hours."mth3_instance_points" = view_month_04_vcpu_hours."mth4_instance_points"))

GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
    , 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65

-- end of create view