-- Create a S3 storage view for the join_month_09_S3_month_09_top_10_s3
CREATE OR REPLACE VIEW "join_month_09_S3_month_09_top_10_s3" AS 
SELECT DISTINCT
  view_09.bill_payer_account_id
, view_09.linked_acct_id
, view_09.prod_code
, view_09.region
, view_09.description
, view_09.unblended_rate
, view_09.storage_class
, view_09.servicecode
, view_09.operation
, view_09.usage_type
, view_09.charge_type
, view_09.year
, view_09.month
, view_09.period
, view_09.mth_order
, view_09.bucket_id
, view_09.usage
, view_09.bucket_cost
, view_09_top_10.line_item_usage_account_id
FROM
  (view_s3_month_09 view_09
INNER JOIN view_s3_month_09_top_10_accts view_09_top_10 ON (view_09.linked_acct_id = view_09_top_10.line_item_usage_account_id))

-- end of create view