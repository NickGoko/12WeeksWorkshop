-- Create a view for join_mth_9_mth_10
CREATE OR REPLACE VIEW "join_mth_9_mth_10" AS 
SELECT
-- Select from view_month_09
  view_month_09."mth9_bill_payer_account_id"
, view_month_09."mth9_linked_acct_id"
, view_month_09."mth9_prod_code"
, view_month_09."mth9_resource_id"
, view_month_09."mth9_description"
, view_month_09."mth9_charge_type"
, view_month_09."mth9_operation"
, view_month_09."mth9_unblended_rate"
, view_month_09."mth9_instance"
, view_month_09."mth9_prod_family"
, view_month_09."mth9_instance_family"
, view_month_09."mth9_instance_type"
, view_month_09."mth9_instance_type_family"
, view_month_09."mth9_tenancy"
, view_month_09."mth9_region"
, view_month_09."mth9_location_type"
, view_month_09."mth9_operating_system"
--, view_month_09."mth9_sp_region"
--, view_month_09."mth9_term_length"
--, view_month_09."mth9_payment_options"
--, view_month_09."mth9_sp_type"
, view_month_09."mth9_sp_arn"
, view_month_09."mth9_sp_rate"
, view_month_09."mth9_storage_class"
, view_month_09."mth9_year"
, view_month_09."mth9_month"
, view_month_09."mth9_payer"
-- Select from view_month_10
, view_month_10."mth10_bill_payer_account_id"
, view_month_10."mth10_linked_acct_id"
, view_month_10."mth10_prod_code"
, view_month_10."mth10_resource_id"
, view_month_10."mth10_description"
, view_month_10."mth10_charge_type"
, view_month_10."mth10_operation"
, view_month_10."mth10_unblended_rate"
, view_month_10."mth10_instance"
, view_month_10."mth10_prod_family"
, view_month_10."mth10_instance_family"
, view_month_10."mth10_instance_type"
, view_month_10."mth10_instance_type_family"
, view_month_10."mth10_tenancy"
, view_month_10."mth10_region"
, view_month_10."mth10_location_type"
, view_month_10."mth10_operating_system"
--, view_month_10."mth10_sp_region"
--, view_month_10."mth10_term_length"
--, view_month_10."mth10_payment_options"
--, view_month_10."mth10_sp_type"
, view_month_10."mth10_sp_arn"
, view_month_10."mth10_sp_rate"
, view_month_10."mth10_storage_class"
, view_month_10."mth10_year"
, view_month_10."mth10_month"
, view_month_10."mth10_payer"

-- update 14-Jan-23: fix filters on control plane
, (CASE WHEN (TRY_CAST(view_month_09."mth9_bill_payer_account_id" AS VARCHAR) IS NULL) THEN view_month_10."mth10_bill_payer_account_id" ELSE view_month_09."mth9_bill_payer_account_id" END) join_9_10_payer
, (CASE WHEN (TRY_CAST(view_month_09."mth9_linked_acct_id" AS VARCHAR) IS NULL) THEN view_month_10."mth10_linked_acct_id" ELSE view_month_09."mth9_linked_acct_id" END) join_9_10_linked_acct_id
, (CASE WHEN (TRY_CAST(view_month_09."mth9_prod_code" AS VARCHAR) IS NULL) THEN view_month_10."mth10_prod_code" ELSE view_month_09."mth9_prod_code" END) join_9_10_prod_code
, (CASE WHEN (TRY_CAST(view_month_09."mth9_resource_id" AS VARCHAR) IS NULL) THEN view_month_10."mth10_resource_id" ELSE view_month_09."mth9_resource_id" END) join_9_10_resource_id
, (CASE WHEN (TRY_CAST(view_month_09."mth9_charge_type" AS VARCHAR) IS NULL) THEN view_month_10."mth10_charge_type" ELSE view_month_09."mth9_charge_type" END) join_9_10_charge_type
, (CASE WHEN (TRY_CAST(view_month_09."mth9_operation" AS VARCHAR) IS NULL) THEN view_month_10."mth10_operation" ELSE view_month_09."mth9_operation" END) join_9_10_operation
, (CASE WHEN (TRY_CAST(view_month_09."mth9_prod_family" AS VARCHAR) IS NULL) THEN view_month_10."mth10_prod_family" ELSE view_month_09."mth9_prod_family" END) join_9_10_prod_family
, (CASE WHEN (TRY_CAST(view_month_09."mth9_instance_family" AS VARCHAR) IS NULL) THEN view_month_10."mth10_instance_family" ELSE view_month_09."mth9_instance_family" END) join_9_10_inst_family
, (CASE WHEN (TRY_CAST(view_month_09."mth9_instance_type" AS VARCHAR) IS NULL) THEN view_month_10."mth10_instance_type" ELSE view_month_09."mth9_instance_type" END) join_9_10_inst_type
, (CASE WHEN (TRY_CAST(view_month_09."mth9_tenancy" AS VARCHAR) IS NULL) THEN view_month_10."mth10_tenancy" ELSE view_month_09."mth9_tenancy" END) join_9_10_tenancy
, (CASE WHEN (TRY_CAST(view_month_09."mth9_region" AS VARCHAR) IS NULL) THEN view_month_10."mth10_region" ELSE view_month_09."mth9_region" END) join_9_10_region
, (CASE WHEN (TRY_CAST(view_month_09."mth9_operating_system" AS VARCHAR) IS NULL) THEN view_month_10."mth10_operating_system" ELSE view_month_09."mth9_operating_system" END) join_9_10_op_system
, (CASE WHEN (TRY_CAST(view_month_09."mth9_sp_arn" AS VARCHAR) IS NULL) THEN view_month_10."mth10_sp_arn" ELSE view_month_09."mth9_sp_arn" END) join_9_10_sp_arn
, (CASE WHEN (TRY_CAST(view_month_09."mth9_storage_class" AS VARCHAR) IS NULL) THEN view_month_10."mth10_storage_class" ELSE view_month_09."mth9_storage_class" END) join_9_10_storage_class

-- end update 14-Jan-23

, TRY_CAST(view_month_09."month_9_cost" AS decimal(16,8)) cur_mth_cost
, TRY_CAST(view_month_09."month_9_usage" AS decimal(16,8)) cur_mth_usg

, TRY_CAST(view_month_10."month_10_cost" AS decimal(16,8)) prev_mth_cost
, TRY_CAST(view_month_10."month_10_usage" AS decimal(16,8)) prev_mth_usg

, (TRY_CAST(view_month_09."month_9_cost" AS decimal(16,8)) - TRY_CAST(view_month_10."month_10_cost" AS decimal(16,8))) cost_var
, (TRY_CAST(view_month_09."month_9_usage" AS decimal(16,8)) - TRY_CAST(view_month_10."month_10_usage" AS decimal(16,8))) usg_var

, (CASE WHEN ((TRY_CAST(view_month_09."month_9_cost" AS decimal(16,8)) - TRY_CAST(view_month_10."month_10_cost" AS decimal(16,8))) < 0) 
THEN "abs"(TRY_CAST((TRY_CAST(view_month_09."month_9_cost" AS decimal(16,8)) - TRY_CAST(view_month_10."month_10_cost" AS decimal(16,8))) AS decimal(16,8))) 
ELSE 0E0 END) savings
, (CASE WHEN ((TRY_CAST(view_month_09."month_9_cost" AS decimal(16,8)) - TRY_CAST(view_month_10."month_10_cost" AS decimal(16,8))) > 0) 
THEN TRY_CAST((TRY_CAST(view_month_09."month_9_cost" AS decimal(16,8)) - TRY_CAST(view_month_10."month_10_cost" AS decimal(16,8))) AS decimal(16,8)) 
ELSE 0E0 END) inc_cost

FROM
 customer_cur_data."view_month_09"

FULL JOIN view_month_10 ON (((((((((((((((((((((view_month_09."mth9_bill_payer_account_id" = view_month_10."mth10_bill_payer_account_id") 
  AND (view_month_09."mth9_linked_acct_id" = view_month_10."mth10_linked_acct_id")) 
  AND (view_month_09."mth9_prod_code" = view_month_10."mth10_prod_code")) 
  AND (view_month_09."mth9_resource_id" = view_month_10."mth10_resource_id")) 
  AND (view_month_09."mth9_description" = view_month_10."mth10_description")) 
  AND (view_month_09."mth9_charge_type" = view_month_10."mth10_charge_type")) 
  AND (view_month_09."mth9_operation" = view_month_10."mth10_operation")) 
  AND (view_month_09."mth9_unblended_rate" = view_month_10."mth10_unblended_rate")) 
  AND (view_month_09."mth9_instance" = view_month_10."mth10_instance")) 
  AND (view_month_09."mth9_prod_family" = view_month_10."mth10_prod_family")) 
  AND (view_month_09."mth9_instance_family" = view_month_10."mth10_instance_family")) 
  AND (view_month_09."mth9_instance_type" = view_month_10."mth10_instance_type")) 
  AND (view_month_09."mth9_instance_type_family" = view_month_10."mth10_instance_type_family")) 
  AND (view_month_09."mth9_tenancy" = view_month_10."mth10_tenancy")) 
  AND (view_month_09."mth9_region" = view_month_10."mth10_region")) 
  AND (view_month_09."mth9_location_type" = view_month_10."mth10_location_type")) 
  AND (view_month_09."mth9_operating_system" = view_month_10."mth10_operating_system")) 
  --AND (view_month_09."mth9_sp_region" = view_month_10."mth10_sp_region")) 
  --AND (view_month_09."mth9_term_length" = view_month_10."mth10_term_length")) 
  --AND (view_month_09."mth9_payment_options" = view_month_10."mth10_payment_options")) 
  --AND (view_month_09."mth9_sp_type" = view_month_10."mth10_sp_type")) 
  AND (view_month_09."mth9_sp_arn" = view_month_10."mth10_sp_arn")) 
  AND (view_month_09."mth9_sp_rate" = view_month_10."mth10_sp_rate")) 
  AND (view_month_09."mth9_storage_class" = view_month_10."mth10_storage_class")) 
  AND (view_month_09."mth9_payer" = view_month_10."mth10_payer"))

GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52
, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66
-- end of create view