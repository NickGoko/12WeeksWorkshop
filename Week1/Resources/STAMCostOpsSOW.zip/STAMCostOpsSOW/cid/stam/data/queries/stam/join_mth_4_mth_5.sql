-- Create a view for join_mth_4_mth_5
CREATE OR REPLACE VIEW "join_mth_4_mth_5" AS 
SELECT
-- Select from view_month_04
  view_month_04."mth4_bill_payer_account_id"
, view_month_04."mth4_linked_acct_id"
, view_month_04."mth4_prod_code"
, view_month_04."mth4_resource_id"
, view_month_04."mth4_description"
, view_month_04."mth4_charge_type"
, view_month_04."mth4_operation"
, view_month_04."mth4_unblended_rate"
, view_month_04."mth4_instance"
, view_month_04."mth4_prod_family"
, view_month_04."mth4_instance_family"
, view_month_04."mth4_instance_type"
, view_month_04."mth4_instance_type_family"
, view_month_04."mth4_tenancy"
, view_month_04."mth4_region"
, view_month_04."mth4_location_type"
, view_month_04."mth4_operating_system"
--, view_month_04."mth4_sp_region"
--, view_month_04."mth4_term_length"
--, view_month_04."mth4_payment_options"
--, view_month_04."mth4_sp_type"
, view_month_04."mth4_sp_arn"
, view_month_04."mth4_sp_rate"
, view_month_04."mth4_storage_class"
, view_month_04."mth4_year"
, view_month_04."mth4_month"
, view_month_04."mth4_payer"
-- Select from view_month_05
, view_month_05."mth5_bill_payer_account_id"
, view_month_05."mth5_linked_acct_id"
, view_month_05."mth5_prod_code"
, view_month_05."mth5_resource_id"
, view_month_05."mth5_description"
, view_month_05."mth5_charge_type"
, view_month_05."mth5_operation"
, view_month_05."mth5_unblended_rate"
, view_month_05."mth5_instance"
, view_month_05."mth5_prod_family"
, view_month_05."mth5_instance_family"
, view_month_05."mth5_instance_type"
, view_month_05."mth5_instance_type_family"
, view_month_05."mth5_tenancy"
, view_month_05."mth5_region"
, view_month_05."mth5_location_type"
, view_month_05."mth5_operating_system"
--, view_month_05."mth5_sp_region"
--, view_month_05."mth5_term_length"
--, view_month_05."mth5_payment_options"
--, view_month_05."mth5_sp_type"
, view_month_05."mth5_sp_arn"
, view_month_05."mth5_sp_rate"
, view_month_05."mth5_storage_class"
, view_month_05."mth5_year"
, view_month_05."mth5_month"
, view_month_05."mth5_payer"

-- update 14-Jan-23: fix filters on control plane
, (CASE WHEN (TRY_CAST(view_month_04."mth4_bill_payer_account_id" AS VARCHAR) IS NULL) THEN view_month_05."mth5_bill_payer_account_id" ELSE view_month_04."mth4_bill_payer_account_id" END) join_4_5_payer
, (CASE WHEN (TRY_CAST(view_month_04."mth4_linked_acct_id" AS VARCHAR) IS NULL) THEN view_month_05."mth5_linked_acct_id" ELSE view_month_04."mth4_linked_acct_id" END) join_4_5_linked_acct_id
, (CASE WHEN (TRY_CAST(view_month_04."mth4_prod_code" AS VARCHAR) IS NULL) THEN view_month_05."mth5_prod_code" ELSE view_month_04."mth4_prod_code" END) join_4_5_prod_code
, (CASE WHEN (TRY_CAST(view_month_04."mth4_resource_id" AS VARCHAR) IS NULL) THEN view_month_05."mth5_resource_id" ELSE view_month_04."mth4_resource_id" END) join_4_5_resource_id
, (CASE WHEN (TRY_CAST(view_month_04."mth4_charge_type" AS VARCHAR) IS NULL) THEN view_month_05."mth5_charge_type" ELSE view_month_04."mth4_charge_type" END) join_4_5_charge_type
, (CASE WHEN (TRY_CAST(view_month_04."mth4_operation" AS VARCHAR) IS NULL) THEN view_month_05."mth5_operation" ELSE view_month_04."mth4_operation" END) join_4_5_operation
, (CASE WHEN (TRY_CAST(view_month_04."mth4_prod_family" AS VARCHAR) IS NULL) THEN view_month_05."mth5_prod_family" ELSE view_month_04."mth4_prod_family" END) join_4_5_prod_family
, (CASE WHEN (TRY_CAST(view_month_04."mth4_instance_family" AS VARCHAR) IS NULL) THEN view_month_05."mth5_instance_family" ELSE view_month_04."mth4_instance_family" END) join_4_5_inst_family
, (CASE WHEN (TRY_CAST(view_month_04."mth4_instance_type" AS VARCHAR) IS NULL) THEN view_month_05."mth5_instance_type" ELSE view_month_04."mth4_instance_type" END) join_4_5_inst_type
, (CASE WHEN (TRY_CAST(view_month_04."mth4_tenancy" AS VARCHAR) IS NULL) THEN view_month_05."mth5_tenancy" ELSE view_month_04."mth4_tenancy" END) join_4_5_tenancy
, (CASE WHEN (TRY_CAST(view_month_04."mth4_region" AS VARCHAR) IS NULL) THEN view_month_05."mth5_region" ELSE view_month_04."mth4_region" END) join_4_5_region
, (CASE WHEN (TRY_CAST(view_month_04."mth4_operating_system" AS VARCHAR) IS NULL) THEN view_month_05."mth5_operating_system" ELSE view_month_04."mth4_operating_system" END) join_4_5_op_system
, (CASE WHEN (TRY_CAST(view_month_04."mth4_sp_arn" AS VARCHAR) IS NULL) THEN view_month_05."mth5_sp_arn" ELSE view_month_04."mth4_sp_arn" END) join_4_5_sp_arn
, (CASE WHEN (TRY_CAST(view_month_04."mth4_storage_class" AS VARCHAR) IS NULL) THEN view_month_05."mth5_storage_class" ELSE view_month_04."mth4_storage_class" END) join_4_5_storage_class

-- end update 14-Jan-23

, TRY_CAST(view_month_04."month_4_cost" AS decimal(16,8)) cur_mth_cost
, TRY_CAST(view_month_04."month_4_usage" AS decimal(16,8)) cur_mth_usg

, TRY_CAST(view_month_05."month_5_cost" AS decimal(16,8)) prev_mth_cost
, TRY_CAST(view_month_05."month_5_usage" AS decimal(16,8)) prev_mth_usg

, (TRY_CAST(view_month_04."month_4_cost" AS decimal(16,8)) - TRY_CAST(view_month_05."month_5_cost" AS decimal(16,8))) cost_var
, (TRY_CAST(view_month_04."month_4_usage" AS decimal(16,8)) - TRY_CAST(view_month_05."month_5_usage" AS decimal(16,8))) usg_var

, (CASE WHEN ((TRY_CAST(view_month_04."month_4_cost" AS decimal(16,8)) - TRY_CAST(view_month_05."month_5_cost" AS decimal(16,8))) < 0) 
THEN "abs"(TRY_CAST((TRY_CAST(view_month_04."month_4_cost" AS decimal(16,8)) - TRY_CAST(view_month_05."month_5_cost" AS decimal(16,8))) AS decimal(16,8))) 
ELSE 0E0 END) savings
, (CASE WHEN ((TRY_CAST(view_month_04."month_4_cost" AS decimal(16,8)) - TRY_CAST(view_month_05."month_5_cost" AS decimal(16,8))) > 0) 
THEN TRY_CAST((TRY_CAST(view_month_04."month_4_cost" AS decimal(16,8)) - TRY_CAST(view_month_05."month_5_cost" AS decimal(16,8))) AS decimal(16,8)) 
ELSE 0E0 END) inc_cost

FROM
 customer_cur_data."view_month_04"

FULL JOIN view_month_05 ON (((((((((((((((((((((view_month_04."mth4_bill_payer_account_id" = view_month_05."mth5_bill_payer_account_id") 
  AND (view_month_04."mth4_linked_acct_id" = view_month_05."mth5_linked_acct_id")) 
  AND (view_month_04."mth4_prod_code" = view_month_05."mth5_prod_code")) 
  AND (view_month_04."mth4_resource_id" = view_month_05."mth5_resource_id")) 
  AND (view_month_04."mth4_description" = view_month_05."mth5_description")) 
  AND (view_month_04."mth4_charge_type" = view_month_05."mth5_charge_type")) 
  AND (view_month_04."mth4_operation" = view_month_05."mth5_operation")) 
  AND (view_month_04."mth4_unblended_rate" = view_month_05."mth5_unblended_rate")) 
  AND (view_month_04."mth4_instance" = view_month_05."mth5_instance")) 
  AND (view_month_04."mth4_prod_family" = view_month_05."mth5_prod_family")) 
  AND (view_month_04."mth4_instance_family" = view_month_05."mth5_instance_family")) 
  AND (view_month_04."mth4_instance_type" = view_month_05."mth5_instance_type")) 
  AND (view_month_04."mth4_instance_type_family" = view_month_05."mth5_instance_type_family")) 
  AND (view_month_04."mth4_tenancy" = view_month_05."mth5_tenancy")) 
  AND (view_month_04."mth4_region" = view_month_05."mth5_region")) 
  AND (view_month_04."mth4_location_type" = view_month_05."mth5_location_type")) 
  AND (view_month_04."mth4_operating_system" = view_month_05."mth5_operating_system")) 
  --AND (view_month_04."mth4_sp_region" = view_month_05."mth5_sp_region")) 
  --AND (view_month_04."mth4_term_length" = view_month_05."mth5_term_length")) 
  --AND (view_month_04."mth4_payment_options" = view_month_05."mth5_payment_options")) 
  --AND (view_month_04."mth4_sp_type" = view_month_05."mth5_sp_type")) 
  AND (view_month_04."mth4_sp_arn" = view_month_05."mth5_sp_arn")) 
  AND (view_month_04."mth4_sp_rate" = view_month_05."mth5_sp_rate")) 
  AND (view_month_04."mth4_storage_class" = view_month_05."mth5_storage_class")) 
  AND (view_month_04."mth4_payer" = view_month_05."mth5_payer"))

GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52
, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66
-- end of create view