-- Create a S3 storage view for the view_s3_month_13_top_10_accts
CREATE OR REPLACE VIEW "view_s3_month_13_top_10_accts" AS 
SELECT DISTINCT
  "line_item_usage_account_id"
, "sum"(TRY_CAST("line_item_unblended_cost" AS decimal(16,8))) total_bucket_cost

FROM
  ${cur_table_name}

WHERE (((("line_item_product_code" LIKE '%S3%') AND ("line_item_resource_id" <> '')) AND (NOT (product_volume_type LIKE 'Tags')))
  AND  ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '13' MONTH)) 
  AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '13' MONTH))) 
  AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '12' MONTH)) 
  AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '12' MONTH)))))

GROUP BY 1

ORDER BY total_bucket_cost DESC

LIMIT 10

-- end of create view