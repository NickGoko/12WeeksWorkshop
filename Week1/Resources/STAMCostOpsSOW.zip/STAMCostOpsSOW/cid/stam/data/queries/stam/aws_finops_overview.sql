-- Create a view for aws_finops_overview
CREATE OR REPLACE VIEW "aws_finops_overview" AS 
-- Select from view join_mth_0_mth_1
SELECT
  "mth0_linked_acct_id" Linked_Acct_ID 
  , "mth0_prod_code" Product_code
  , "mth0_charge_type" Charge_Type 
  , "mth0_operation" Operation 
  , "mth0_prod_family" Product_Family 
  , "mth0_instance_family" Instance_Family 
  , "mth0_instance_type" Instance_Type 
  , "mth0_storage_class" Storage_Class
  , "mth0_year" Year
  , "mth0_month" Month
  , "mth0_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost 
  , "savings" Total_Savings 
  , "inc_cost" Total_Increased_Cost 
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth0_month AS integer) < 10) AND ("substring"(mth0_month, 1, 1) <> '0')) 
  THEN "concat"(mth0_year, ' - ','0',  mth0_month) ELSE "concat"(mth0_year, ' - ', mth0_month) END) period
  , (CASE WHEN ((TRY_CAST(mth0_month AS integer) < 10) AND ("substring"(mth0_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth0_month) ELSE mth0_month END) mth_order

FROM
  "customer_cur_data"."join_mth_0_mth_1"
-- Combine with view join_mth_1_mth_2
UNION ALL 
SELECT
  "mth1_linked_acct_id" Linked_Acct_ID
  , "mth1_prod_code" Product_code
  , "mth1_charge_type" Charge_Type
  , "mth1_operation" Operation
  , "mth1_prod_family" Product_Family
  , "mth1_instance_family" Instance_Family
  , "mth1_instance_type" Instance_Type 
  , "mth1_storage_class" Storage_Class
  , "mth1_year" Year
  , "mth1_month" Month
  , "mth1_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth1_month AS integer) < 10) AND ("substring"(mth1_month, 1, 1) <> '0')) 
  THEN "concat"(mth1_year, ' - ','0',  mth1_month) ELSE "concat"(mth1_year, ' - ', mth1_month) END) period
  , (CASE WHEN ((TRY_CAST(mth1_month AS integer) < 10) AND ("substring"(mth1_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth1_month) ELSE mth1_month END) mth_order
 
FROM
  "customer_cur_data"."join_mth_1_mth_2"
-- Combine with view join_mth_2_mth_3
UNION ALL 
SELECT
  "mth2_linked_acct_id" Linked_Acct_ID
  , "mth2_prod_code" Product_code
  , "mth2_charge_type" Charge_Type
  , "mth2_operation" Operation
  , "mth2_prod_family" Product_Family
  , "mth2_instance_family" Instance_Family
  , "mth2_instance_type" Instance_Type 
  , "mth2_storage_class" Storage_Class
  , "mth2_year" Year
  , "mth2_month" Month
  , "mth2_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth2_month AS integer) < 10) AND ("substring"(mth2_month, 1, 1) <> '0')) 
  THEN "concat"(mth2_year, ' - ','0',  mth2_month) ELSE "concat"(mth2_year, ' - ', mth2_month) END) period
  , (CASE WHEN ((TRY_CAST(mth2_month AS integer) < 10) AND ("substring"(mth2_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth2_month) ELSE mth2_month END) mth_order

FROM
  "customer_cur_data"."join_mth_2_mth_3"
-- Combine with view join_mth_3_mth_4
UNION ALL 
SELECT
  "mth3_linked_acct_id" Linked_Acct_ID
  , "mth3_prod_code" Product_code
  , "mth3_charge_type" Charge_Type
  , "mth3_operation" Operation
  , "mth3_prod_family" Product_Family
  , "mth3_instance_family" Instance_Family
  , "mth3_instance_type" Instance_Type 
  , "mth3_storage_class" Storage_Class
  , "mth3_year" Year
  , "mth3_month" Month
  , "mth3_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth3_month AS integer) < 10) AND ("substring"(mth3_month, 1, 1) <> '0')) 
  THEN "concat"(mth3_year, ' - ','0',  mth3_month) ELSE "concat"(mth3_year, ' - ', mth3_month) END) period
  , (CASE WHEN ((TRY_CAST(mth3_month AS integer) < 10) AND ("substring"(mth3_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth3_month) ELSE mth3_month END) mth_order

FROM
  "customer_cur_data"."join_mth_3_mth_4"
-- Combine with view join_mth_4_mth_5
UNION ALL 
SELECT
  "mth4_linked_acct_id" Linked_Acct_ID
  , "mth4_prod_code" Product_code
  , "mth4_charge_type" Charge_Type
  , "mth4_operation" Operation
  , "mth4_prod_family" Product_Family
  , "mth4_instance_family" Instance_Family
  , "mth4_instance_type" Instance_Type 
  , "mth4_storage_class" Storage_Class
  , "mth4_year" Year
  , "mth4_month" Month
  , "mth4_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth4_month AS integer) < 10) AND ("substring"(mth4_month, 1, 1) <> '0')) 
  THEN "concat"(mth4_year, ' - ','0',  mth4_month) ELSE "concat"(mth4_year, ' - ', mth4_month) END) period
  , (CASE WHEN ((TRY_CAST(mth4_month AS integer) < 10) AND ("substring"(mth4_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth4_month) ELSE mth4_month END) mth_order

FROM
  "customer_cur_data"."join_mth_4_mth_5"
-- Combine with view join_mth_5_mth_6
UNION ALL 
SELECT
  "mth5_linked_acct_id" Linked_Acct_ID
  , "mth5_prod_code" Product_code
  , "mth5_charge_type" Charge_Type
  , "mth5_operation" Operation
  , "mth5_prod_family" Product_Family
  , "mth5_instance_family" Instance_Family
  , "mth5_instance_type" Instance_Type 
  , "mth5_storage_class" Storage_Class
  , "mth5_year" Year
  , "mth5_month" Month
  , "mth5_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth5_month AS integer) < 10) AND ("substring"(mth5_month, 1, 1) <> '0')) 
  THEN "concat"(mth5_year, ' - ','0',  mth5_month) ELSE "concat"(mth5_year, ' - ', mth5_month) END) period
  , (CASE WHEN ((TRY_CAST(mth5_month AS integer) < 10) AND ("substring"(mth5_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth5_month) ELSE mth5_month END) mth_order
 
FROM
  "customer_cur_data"."join_mth_5_mth_6"
-- Combine with view join_mth_6_mth_7
UNION ALL 
SELECT
  "mth6_linked_acct_id" Linked_Acct_ID
  , "mth6_prod_code" Product_code
  , "mth6_charge_type" Charge_Type
  , "mth6_operation" Operation
  , "mth6_prod_family" Product_Family
  , "mth6_instance_family" Instance_Family
  , "mth6_instance_type" Instance_Type 
  , "mth6_storage_class" Storage_Class
  , "mth6_year" Year
  , "mth6_month" Month
  , "mth6_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth6_month AS integer) < 10) AND ("substring"(mth6_month, 1, 1) <> '0')) 
  THEN "concat"(mth6_year, ' - ','0',  mth6_month) ELSE "concat"(mth6_year, ' - ', mth6_month) END) period
  , (CASE WHEN ((TRY_CAST(mth6_month AS integer) < 10) AND ("substring"(mth6_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth6_month) ELSE mth6_month END) mth_order

FROM
  "customer_cur_data"."join_mth_6_mth_7"
-- Combine with view join_mth_7_mth_8
UNION ALL 
SELECT
  "mth7_linked_acct_id" Linked_Acct_ID
  , "mth7_prod_code" Product_code
  , "mth7_charge_type" Charge_Type
  , "mth7_operation" Operation
  , "mth7_prod_family" Product_Family
  , "mth7_instance_family" Instance_Family
  , "mth7_instance_type" Instance_Type 
  , "mth7_storage_class" Storage_Class
  , "mth7_year" Year
  , "mth7_month" Month
  , "mth7_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth7_month AS integer) < 10) AND ("substring"(mth7_month, 1, 1) <> '0')) 
  THEN "concat"(mth7_year, ' - ','0',  mth7_month) ELSE "concat"(mth7_year, ' - ', mth7_month) END) period
  , (CASE WHEN ((TRY_CAST(mth7_month AS integer) < 10) AND ("substring"(mth7_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth7_month) ELSE mth7_month END) mth_order

FROM
  "customer_cur_data"."join_mth_7_mth_8"
-- Combine with view join_mth_8_mth_9
UNION ALL 
SELECT
  "mth8_linked_acct_id" Linked_Acct_ID
  , "mth8_prod_code" Product_code
  , "mth8_charge_type" Charge_Type
  , "mth8_operation" Operation
  , "mth8_prod_family" Product_Family
  , "mth8_instance_family" Instance_Family
  , "mth8_instance_type" Instance_Type 
  , "mth8_storage_class" Storage_Class
  , "mth8_year" Year
  , "mth8_month" Month
  , "mth8_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth8_month AS integer) < 10) AND ("substring"(mth8_month, 1, 1) <> '0')) 
  THEN "concat"(mth8_year, ' - ','0',  mth8_month) ELSE "concat"(mth8_year, ' - ', mth8_month) END) period
  , (CASE WHEN ((TRY_CAST(mth8_month AS integer) < 10) AND ("substring"(mth8_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth8_month) ELSE mth8_month END) mth_order
 
FROM
  "customer_cur_data"."join_mth_8_mth_9"
-- Combine with view join_mth_9_mth_10
UNION ALL 
SELECT
  "mth9_linked_acct_id" Linked_Acct_ID
  , "mth9_prod_code" Product_code
  , "mth9_charge_type" Charge_Type
  , "mth9_operation" Operation
  , "mth9_prod_family" Product_Family
  , "mth9_instance_family" Instance_Family
  , "mth9_instance_type" Instance_Type 
  , "mth9_storage_class" Storage_Class
  , "mth9_year" Year
  , "mth9_month" Month
  , "mth9_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth9_month AS integer) < 10) AND ("substring"(mth9_month, 1, 1) <> '0')) 
  THEN "concat"(mth9_year, ' - ','0',  mth9_month) ELSE "concat"(mth9_year, ' - ', mth9_month) END) period
  , (CASE WHEN ((TRY_CAST(mth9_month AS integer) < 10) AND ("substring"(mth9_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth9_month) ELSE mth9_month END) mth_order

FROM
  "customer_cur_data"."join_mth_9_mth_10"
-- Combine with view join_mth_10_mth_11
UNION ALL 
SELECT
  "mth10_linked_acct_id" Linked_Acct_ID
  , "mth10_prod_code" Product_code
  , "mth10_charge_type" Charge_Type
  , "mth10_operation" Operation
  , "mth10_prod_family" Product_Family
  , "mth10_instance_family" Instance_Family
  , "mth10_instance_type" Instance_Type 
  , "mth10_storage_class" Storage_Class
  , "mth10_year" Year
  , "mth10_month" Month
  , "mth10_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth10_month AS integer) < 10) AND ("substring"(mth10_month, 1, 1) <> '0')) 
  THEN "concat"(mth10_year, ' - ','0',  mth10_month) ELSE "concat"(mth10_year, ' - ', mth10_month) END) period
  , (CASE WHEN ((TRY_CAST(mth10_month AS integer) < 10) AND ("substring"(mth10_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth10_month) ELSE mth10_month END) mth_order

FROM
  "customer_cur_data"."join_mth_10_mth_11"
-- Combine with view join_mth_11_mth_12
UNION ALL 
SELECT
  "mth11_linked_acct_id" Linked_Acct_ID
  , "mth11_prod_code" Product_code
  , "mth11_charge_type" Charge_Type
  , "mth11_operation" Operation
  , "mth11_prod_family" Product_Family
  , "mth11_instance_family" Instance_Family
  , "mth11_instance_type" Instance_Type 
  , "mth11_storage_class" Storage_Class
  , "mth11_year" Year
  , "mth11_month" Month
  , "mth11_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth11_month AS integer) < 10) AND ("substring"(mth11_month, 1, 1) <> '0')) 
  THEN "concat"( mth11_year, ' - ','0', mth11_month) ELSE "concat"(mth11_year, ' - ', mth11_month) END) period
  , (CASE WHEN ((TRY_CAST(mth11_month AS integer) < 10) AND ("substring"(mth11_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth11_month) ELSE mth11_month END) mth_order

FROM
  "customer_cur_data"."join_mth_11_mth_12"
-- Combine with view join_mth_12_mth_13
UNION ALL 
SELECT
  "mth12_linked_acct_id" Linked_Acct_ID
  , "mth12_prod_code" Product_code
  , "mth12_charge_type" Charge_Type
  , "mth12_operation" Operation
  , "mth12_prod_family" Product_Family
  , "mth12_instance_family" Instance_Family
  , "mth12_instance_type" Instance_Type 
  , "mth12_storage_class" Storage_Class
  , "mth12_year" Year
  , "mth12_month" Month
  , "mth12_payer" Payer_Acct_ID
  , "cur_mth_cost" Total_Cost
  , "savings" Total_Savings
  , "inc_cost" Total_Increased_Cost
  , "cost_var" Total_Cost_Var
  , (CASE WHEN ((TRY_CAST(mth12_month AS integer) < 10) AND ("substring"(mth12_month, 1, 1) <> '0')) 
  THEN "concat"( mth12_year, ' - ','0', mth12_month) ELSE "concat"(mth12_year, ' - ', mth12_month) END) period
  , (CASE WHEN ((TRY_CAST(mth12_month AS integer) < 10) AND ("substring"(mth12_month, 1, 1) <> '0')) 
  THEN "concat"('0', mth12_month) ELSE mth12_month END) mth_order

FROM
  "customer_cur_data"."join_mth_12_mth_13"
-- end of create view