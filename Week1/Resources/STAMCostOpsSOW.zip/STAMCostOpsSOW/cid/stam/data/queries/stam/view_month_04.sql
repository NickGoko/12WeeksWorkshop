-- Create a view for the 4th prior month
CREATE OR REPLACE VIEW "view_month_04" AS 
SELECT DISTINCT
  month_4."bill_payer_account_id" mth4_bill_payer_account_id
  , month_4."line_item_usage_account_id" mth4_linked_acct_id
  , month_4."line_item_product_code" mth4_prod_code
  , month_4."line_item_resource_id" mth4_resource_id
  , month_4."line_item_line_item_description" mth4_description
  , month_4."line_item_line_item_type" mth4_charge_type
  , month_4."line_item_operation" mth4_operation
  , month_4."line_item_unblended_rate" mth4_unblended_rate
  , month_4."product_instance_type" mth4_instance
  , month_4."product_product_family" mth4_prod_family
  , month_4."product_instance_family" mth4_instance_family
  , month_4."product_instance_type" mth4_instance_type
  , month_4."product_instance_type_family" mth4_instance_type_family
  , month_4."product_tenancy" mth4_tenancy
  , month_4."product_location" mth4_region
  , month_4."product_location_type" mth4_location_type
  , month_4."product_operating_system" mth4_operating_system
--  , month_4."savings_plan_region" mth4_sp_region
--  , month_4."savings_plan_purchase_term" mth4_term_length
--  , month_4."savings_plan_payment_option" mth4_payment_options
--  , month_4."savings_plan_offering_type" mth4_sp_type
  , month_4."savings_plan_savings_plan_a_r_n" mth4_sp_arn
  , month_4."savings_plan_savings_plan_rate" mth4_sp_rate
  , month_4."product_volume_type" mth4_storage_class
  , "sum"(TRY_CAST(month_4."line_item_unblended_cost" AS decimal(16,8))) month_4_cost
  , "sum"(TRY_CAST(month_4."line_item_usage_amount" AS decimal(16,8))) month_4_usage
  , month_4."year" mth4_year
  , month_4."month" mth4_month
  , month_4."bill_payer_account_id" mth4_payer
FROM
  "customer_all" month_4
WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '4' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '4' MONTH))) AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '3' MONTH)) AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '3' MONTH))))
GROUP BY "bill_payer_account_id"
    , "line_item_usage_account_id"
    , "line_item_product_code"
    , "line_item_resource_id"
    , "line_item_line_item_description"
    , "line_item_line_item_type"
    , "line_item_operation"
    , "line_item_unblended_rate"
    , "product_instance_type"
    , "product_product_family"
    , "savings_plan_savings_plan_a_r_n"
    , "savings_plan_savings_plan_rate"
    , "product_volume_type"
    , "year"
    , "month"
    , "product_instance_type_family"
    , "product_tenancy"
    , "product_location"
    , "product_location_type"
    , "product_operating_system"
--    , "savings_plan_region"
--    , "savings_plan_purchase_term"
--    , "savings_plan_payment_option"
--    , "savings_plan_offering_type"
    , "product_instance_family"
    , "product_instance_type"
-- end of create view