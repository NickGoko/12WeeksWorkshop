-- Create a sustainability view for the view_transfer_data
CREATE OR REPLACE VIEW "view_transfer_data" AS 
SELECT
  "line_item_product_code"
, "line_item_usage_account_id"
, "date_format"("line_item_usage_start_date", '%Y-%m-%d') date_line_item_usage_start_date
, "line_item_usage_type"
, "product_from_location"
, "product_to_location"
, "product_product_family"
, "line_item_resource_id"
, "bill_billing_period_start_date"
, "product_transfer_type"
, "product_to_location_type"
, "product_from_location_type"
, "year"
, "month"
, "line_item_line_item_type"
, "line_item_operation"
, "line_item_line_item_description"
, "bill_payer_account_id"

, "sum"(CAST("line_item_usage_amount" AS double)) sum_line_item_usage_amount
, "sum"(CAST("line_item_unblended_cost" AS decimal(16,8))) sum_line_item_unblended_cost
FROM
  "${cur_table_name}"

WHERE ((((product_product_family = 'Data Transfer') 
    AND (line_item_line_item_type = 'Usage')) 
    AND (line_item_line_item_type IN ('DiscountedUsage', 'Usage', 'SavingsPlanCoveredUsage'))) 
    AND (("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '24' MONTH)) 
    AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '24' MONTH))))

GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18

-- end of create view