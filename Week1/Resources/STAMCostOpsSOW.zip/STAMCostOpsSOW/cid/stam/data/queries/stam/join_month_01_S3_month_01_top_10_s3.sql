-- Create a S3 storage view for the join_month_01_S3_month_01_top_10_s3
CREATE OR REPLACE VIEW "join_month_01_S3_month_01_top_10_s3" AS 
SELECT DISTINCT
  view_01.bill_payer_account_id
, view_01.linked_acct_id
, view_01.prod_code
, view_01.region
, view_01.description
, view_01.unblended_rate
, view_01.storage_class
, view_01.servicecode
, view_01.operation
, view_01.usage_type
, view_01.charge_type
, view_01.year
, view_01.month
, view_01.period
, view_01.mth_order
, view_01.bucket_id
, view_01.usage
, view_01.bucket_cost
, view_01_top_10.line_item_usage_account_id
FROM
  (view_s3_month_01 view_01
INNER JOIN view_s3_month_01_top_10_accts view_01_top_10 ON (view_01.linked_acct_id = view_01_top_10.line_item_usage_account_id))

-- end of create view