-- Create a sustainability view for the 9th prior month
CREATE OR REPLACE VIEW "view_month_10_vcpu_hours" AS 
SELECT
  month_10."bill_payer_account_id" mth10_bill_payer_account_id
, month_10."line_item_usage_account_id" mth10_linked_acct_id
, month_10."line_item_product_code" mth10_prod_code
, month_10."product_region" mth10_region
, month_10."product_servicecode" mth10_servicecode
, month_10."line_item_operation" mth10_operation
, month_10."line_item_usage_type" mth10_usage_type
, month_10."line_item_line_item_type" mth10_charge_type
, month_10."pricing_term" mth10_pricing_term
, month_10."product_clock_speed" mth10_clock_speed
, month_10."product_instance_family" mth10_inst_family
, month_10."product_instance_type" mth10_instance
, month_10."product_instance_type_family" mth10_instance_type_family
, TRY_CAST(month_10."product_vcpu" AS int) mth10_vcpu_count
, month_10."year" mth10_year
, month_10."month" mth10_month
, month_10."line_item_resource_id" mth10_instance_id
, "split_part"(month_10."product_instance_type", '.', 1) mth10_instance_family
, (CASE 
	WHEN (((((month_10."product_region" = 'eu-west-1') 
	OR (month_10."product_region" = 'eu-central-1')) 
	OR (month_10."product_region" = 'ca-central-1')) 
	OR (month_10."product_region" = 'us-gov-west-1')) 
	OR (month_10."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END) mth10_r_points
, (CASE 
	WHEN ("split_part"(month_10."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END) mth10_instance_points
, "sum"(TRY_CAST(month_10."line_item_usage_amount" AS decimal(16,8))) mth10_instance_hours
, "sum"(TRY_CAST(month_10."line_item_unblended_cost" AS decimal(16,8))) mth10_od_instance_cost
, "sum"(TRY_CAST(month_10."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) mth10_sp_instance_cost


-- Calculate key metrics for sustainability

-- Key Metric: vcpu hours
, (TRY_CAST("product_vcpu" AS int)
	*("sum"(TRY_CAST(month_10."line_item_usage_amount" AS decimal(16,8))))) mth10_vcpu_hours

-- Key Metric: spot vcpu hours
,(CASE 
	WHEN (month_10."pricing_term" = '')
	THEN (TRY_CAST(month_10."product_vcpu" AS int)*("sum"(TRY_CAST(month_10."line_item_usage_amount" AS decimal(16,8)))))
	ELSE 0
	END) mth10_spot_vcpu_hours

-- Key Metric: EC2 Sustainability Points
, (((TRY_CAST("product_vcpu" AS int)
	*("sum"(TRY_CAST(month_10."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_10."product_region" = 'eu-west-1') 
	OR (month_10."product_region" = 'eu-central-1')) 
	OR (month_10."product_region" = 'ca-central-1')) 
	OR (month_10."product_region" = 'us-gov-west-1')) 
	OR (month_10."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_10."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)) mth10_ec2_sustainability_points

-- Key Metric: Instance Cost
,(CASE
	WHEN (("sum"(TRY_CAST(month_10."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_10."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_10."line_item_unblended_cost" AS decimal(16,8))))
	END) mth10_instance_cost

-- Key Metric: Cost per Sustainability Point
,(((CASE
	WHEN (("sum"(TRY_CAST(month_10."savings_plan_savings_plan_effective_cost" AS decimal(16,8))) != 0))
	THEN ("sum"(TRY_CAST(month_10."savings_plan_savings_plan_effective_cost" AS decimal(16,8))))
	ELSE ("sum"(TRY_CAST(month_10."line_item_unblended_cost" AS decimal(16,8))))
	END))/((((TRY_CAST(month_10."product_vcpu" AS int)
	*("sum"(TRY_CAST(month_10."line_item_usage_amount" AS decimal(16,8))))))
	* (CASE 
	WHEN (((((month_10."product_region" = 'eu-west-1') 
	OR (month_10."product_region" = 'eu-central-1')) 
	OR (month_10."product_region" = 'ca-central-1')) 
	OR (month_10."product_region" = 'us-gov-west-1')) 
	OR (month_10."product_region" = 'us-west-2')) 
	THEN 1 
	ELSE 2 
	END)
	*(CASE 
	WHEN ("split_part"(month_10."product_instance_type", '.', 1) = '%g%') 
	THEN 1 
	ELSE 2 
	END)))) mth10_Cost_per_Sus_Point

FROM
  "customer_all" month_10

WHERE ((("bill_billing_period_start_date" >= ("date_trunc"('month', current_timestamp) - INTERVAL  '10' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) >= ("date_trunc"('month', current_date) - INTERVAL  '10' MONTH))) 
	AND (("bill_billing_period_start_date" < ("date_trunc"('month', current_timestamp) - INTERVAL  '9' MONTH)) 
	AND (CAST("concat"("year", '-', "month", '-01') AS date) < ("date_trunc"('month', current_date) - INTERVAL  '9' MONTH))))

AND
	(((((month_10."line_item_product_code" = 'AmazonEC2') 
	AND (month_10."product_servicecode" <> 'AWSDataTransfer')) 
	AND (month_10."line_item_operation" LIKE '%RunInstances%')) 
	AND (NOT (month_10."line_item_usage_type" LIKE '%DataXfer%'))) 
	AND (((month_10."line_item_line_item_type" = 'Usage') 
	OR (month_10."line_item_line_item_type" = 'SavingsPlanCoveredUsage')) 
	OR (month_10."line_item_line_item_type" = 'DiscountedUsage')))

GROUP BY "bill_payer_account_id"
	, "line_item_usage_account_id"
	, "line_item_product_code"
	, "product_region"
	, "product_servicecode"
	, "line_item_operation"
	, "line_item_usage_type"
	, "line_item_line_item_type"
	, "pricing_term"
	, "product_clock_speed"
	, "product_instance_family"
	, "product_instance_type"
	, "product_instance_type_family"
	, "product_vcpu"
	, "year"
	, "month"
	, "line_item_resource_id"
-- end of create view