CREATE OR REPLACE VIEW "view_savings_plan_analysis_nosp" AS 
SELECT DISTINCT
  "date_trunc"('hour', "line_item_usage_start_date") start_date
, "date_trunc"('hour', "line_item_usage_end_date") end_date
, "line_item_resource_id" resource_id
, "year"
, "month"
, "savings_plan_savings_plan_rate" sp_rate
, "savings_plan_used_commitment" sp_used_commitment
, "savings_plan_savings_plan_a_r_n" sp_arn
, "line_item_line_item_type" charge_type
, "bill_payer_account_id" payer
, "line_item_usage_account_id" linked_acct_id
, "line_item_product_code" product_code
, "product_instance_family" instance_family
, "product_instance_type" instance_type
, "product_tenancy" tenancy
, "product_volume_type" storage_class
, "product_location" region
, "product_location_type" location_type
, "product_operating_system" operating_system
, "product_vcpu"
, "line_item_operation" operation
, "line_item_line_item_description" description
, "line_item_unblended_rate" OnDemand_rate
, "pricing_term" pricing_term
, "line_item_usage_type" usg_type
, "savings_plan_amortized_upfront_commitment_for_billing_period" sp_amortised_upfront_commitment
, "savings_plan_recurring_commitment_for_billing_period" sp_recurring_commitment
, "savings_plan_savings_plan_effective_cost" sp_effective_cost
, "product_instance_type_family" instance_type_family
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE '')) THEN CAST(line_item_usage_amount AS double) ELSE 0 END)) Spot_Usage
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE '')) THEN CAST(line_item_unblended_cost AS decimal(16,8)) ELSE 0 END)) Spot_Cost
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE 'Reserved')) THEN CAST(line_item_usage_amount AS double) ELSE 0 END)) RI_Usage
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE 'Reserved')) THEN CAST(line_item_unblended_cost AS decimal(16,8)) ELSE 0 END)) RI_Cost
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE 'OnDemand')) THEN (CASE line_item_line_item_type WHEN 'SavingsPlanCoveredUsage' THEN CAST(line_item_usage_amount AS double) ELSE 0 END) ELSE 0 END)) SavingsPlans_Usage
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE 'OnDemand')) THEN (CASE line_item_line_item_type WHEN 'SavingsPlanCoveredUsage' THEN CAST(line_item_unblended_cost AS decimal(16,8)) ELSE 0 END) ELSE 0 END)) SavingsPlans_Cost
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE 'OnDemand')) THEN (CASE line_item_line_item_type WHEN 'Usage' THEN CAST(line_item_usage_amount AS double) ELSE 0 END) ELSE 0 END)) OnDemand_Usage
, "sum"((CASE WHEN ((NOT (line_item_product_code LIKE '%SavingsPlans%')) AND (pricing_term LIKE 'OnDemand')) THEN (CASE line_item_line_item_type WHEN 'Usage' THEN CAST(line_item_unblended_cost AS decimal(16,8)) ELSE 0 END) ELSE 0 END)) OnDemand_Cost
, "sum"(CASE WHEN (TRY_CAST("savings_plan_savings_plan_rate" AS decimal(16,8)) > 0E0) THEN (TRY_CAST("line_item_unblended_cost" AS decimal(16,8)) - TRY_CAST("savings_plan_savings_plan_effective_cost" AS decimal(16,8))) ELSE 0E0 END) savings
, "sum"((CASE WHEN (line_item_product_code LIKE '%SavingsPlans%') THEN CAST(line_item_unblended_cost AS double) ELSE 0 END)) Plan_Cost
, "sum"(CASE WHEN (TRY_CAST("line_item_unblended_cost" AS decimal(16,8)) > 0E0) THEN ((TRY_CAST("line_item_unblended_cost" AS decimal(16,8)) - TRY_CAST("savings_plan_savings_plan_effective_cost" AS decimal(16,8))) / TRY_CAST("line_item_unblended_cost" AS decimal(16,8))) ELSE 0E0 END) percentage_savings
, (CASE WHEN ((TRY_CAST("month" AS integer) < 10) AND ("substring"("month", 1, 1) <> '0')) THEN "concat"("year", ' - ', '0', "month") ELSE "concat"("year", ' - ', "month") END) period
FROM
  "customer_all"
WHERE (((line_item_product_code = 'AmazonEC2') AND ((line_item_usage_type LIKE '%BoxUsage%') OR (line_item_usage_type LIKE '%Spot%'))) OR (((line_item_product_code LIKE '%SavingsPlans%') AND ("line_item_unblended_cost" <> 0)) AND ("line_item_usage_type" <> '')))
GROUP BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29
