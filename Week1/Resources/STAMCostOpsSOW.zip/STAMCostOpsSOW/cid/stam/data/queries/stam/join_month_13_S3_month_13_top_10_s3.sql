-- Create a S3 storage view for the join_month_13_S3_month_13_top_10_s3
CREATE OR REPLACE VIEW "join_month_13_S3_month_13_top_10_s3" AS 
SELECT DISTINCT
  view_13.bill_payer_account_id
, view_13.linked_acct_id
, view_13.prod_code
, view_13.region
, view_13.description
, view_13.unblended_rate
, view_13.storage_class
, view_13.servicecode
, view_13.operation
, view_13.usage_type
, view_13.charge_type
, view_13.year
, view_13.month
, view_13.period
, view_13.mth_order
, view_13.bucket_id
, view_13.usage
, view_13.bucket_cost
, view_13_top_10.line_item_usage_account_id
FROM
  (view_s3_month_13 view_13
INNER JOIN view_s3_month_13_top_10_accts view_13_top_10 ON (view_13.linked_acct_id = view_13_top_10.line_item_usage_account_id))

-- end of create view