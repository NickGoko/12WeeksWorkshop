-- Create a S3 storage view for the aws_top_10_s3_overview
CREATE OR REPLACE VIEW "aws_top_10_s3_overview" AS 
SELECT DISTINCT
  view_0.bill_payer_account_id
, view_0.linked_acct_id
, view_0.prod_code
, view_0.region
, view_0.description
, view_0.unblended_rate
, view_0.storage_class
, view_0.servicecode
, view_0.operation
, view_0.usage_type
, view_0.charge_type
, view_0.year
, view_0.month
, view_0.period
, view_0.mth_order
, view_0.bucket_id
, view_0.usage
, view_0.bucket_cost
, view_0.line_item_usage_account_id
FROM
  	join_month_0_S3_month_0_top_10_s3 view_0
UNION ALL
SELECT 
  view_01.bill_payer_account_id
, view_01.linked_acct_id
, view_01.prod_code
, view_01.region
, view_01.description
, view_01.unblended_rate
, view_01.storage_class
, view_01.servicecode
, view_01.operation
, view_01.usage_type
, view_01.charge_type
, view_01.year
, view_01.month
, view_01.period
, view_01.mth_order
, view_01.bucket_id
, view_01.usage
, view_01.bucket_cost
, view_01.line_item_usage_account_id
FROM
 	join_month_01_S3_month_01_top_10_s3 view_01
UNION ALL
SELECT 
  view_02.bill_payer_account_id
, view_02.linked_acct_id
, view_02.prod_code
, view_02.region
, view_02.description
, view_02.unblended_rate
, view_02.storage_class
, view_02.servicecode
, view_02.operation
, view_02.usage_type
, view_02.charge_type
, view_02.year
, view_02.month
, view_02.period
, view_02.mth_order
, view_02.bucket_id
, view_02.usage
, view_02.bucket_cost
, view_02.line_item_usage_account_id
FROM
  join_month_02_S3_month_02_top_10_s3 view_02

UNION ALL
SELECT 
  view_03.bill_payer_account_id
, view_03.linked_acct_id
, view_03.prod_code
, view_03.region
, view_03.description
, view_03.unblended_rate
, view_03.storage_class
, view_03.servicecode
, view_03.operation
, view_03.usage_type
, view_03.charge_type
, view_03.year
, view_03.month
, view_03.period
, view_03.mth_order
, view_03.bucket_id
, view_03.usage
, view_03.bucket_cost
, view_03.line_item_usage_account_id
FROM
 join_month_03_S3_month_03_top_10_s3 view_03

UNION ALL
SELECT 
  view_04.bill_payer_account_id
, view_04.linked_acct_id
, view_04.prod_code
, view_04.region
, view_04.description
, view_04.unblended_rate
, view_04.storage_class
, view_04.servicecode
, view_04.operation
, view_04.usage_type
, view_04.charge_type
, view_04.year
, view_04.month
, view_04.period
, view_04.mth_order
, view_04.bucket_id
, view_04.usage
, view_04.bucket_cost
, view_04.line_item_usage_account_id
FROM
  join_month_04_S3_month_04_top_10_s3 view_04

UNION ALL
SELECT 
  view_05.bill_payer_account_id
, view_05.linked_acct_id
, view_05.prod_code
, view_05.region
, view_05.description
, view_05.unblended_rate
, view_05.storage_class
, view_05.servicecode
, view_05.operation
, view_05.usage_type
, view_05.charge_type
, view_05.year
, view_05.month
, view_05.period
, view_05.mth_order
, view_05.bucket_id
, view_05.usage
, view_05.bucket_cost
, view_05.line_item_usage_account_id
FROM
 join_month_05_S3_month_05_top_10_s3 view_05


UNION ALL
SELECT 
  view_06.bill_payer_account_id
, view_06.linked_acct_id
, view_06.prod_code
, view_06.region
, view_06.description
, view_06.unblended_rate
, view_06.storage_class
, view_06.servicecode
, view_06.operation
, view_06.usage_type
, view_06.charge_type
, view_06.year
, view_06.month
, view_06.period
, view_06.mth_order
, view_06.bucket_id
, view_06.usage
, view_06.bucket_cost
, view_06.line_item_usage_account_id
FROM
  join_month_06_S3_month_06_top_10_s3 view_06


UNION ALL
SELECT 
  view_07.bill_payer_account_id
, view_07.linked_acct_id
, view_07.prod_code
, view_07.region
, view_07.description
, view_07.unblended_rate
, view_07.storage_class
, view_07.servicecode
, view_07.operation
, view_07.usage_type
, view_07.charge_type
, view_07.year
, view_07.month
, view_07.period
, view_07.mth_order
, view_07.bucket_id
, view_07.usage
, view_07.bucket_cost
, view_07.line_item_usage_account_id
FROM
  join_month_07_S3_month_07_top_10_s3 view_07


UNION ALL

SELECT 
  view_08.bill_payer_account_id
, view_08.linked_acct_id
, view_08.prod_code
, view_08.region
, view_08.description
, view_08.unblended_rate
, view_08.storage_class
, view_08.servicecode
, view_08.operation
, view_08.usage_type
, view_08.charge_type
, view_08.year
, view_08.month
, view_08.period
, view_08.mth_order
, view_08.bucket_id
, view_08.usage
, view_08.bucket_cost
, view_08.line_item_usage_account_id
FROM
  join_month_08_S3_month_08_top_10_s3 view_08

UNION ALL
SELECT 
  view_09.bill_payer_account_id
, view_09.linked_acct_id
, view_09.prod_code
, view_09.region
, view_09.description
, view_09.unblended_rate
, view_09.storage_class
, view_09.servicecode
, view_09.operation
, view_09.usage_type
, view_09.charge_type
, view_09.year
, view_09.month
, view_09.period
, view_09.mth_order
, view_09.bucket_id
, view_09.usage
, view_09.bucket_cost
, view_09.line_item_usage_account_id
FROM
  join_month_09_S3_month_09_top_10_s3 view_09

UNION ALL
SELECT 
  view_10.bill_payer_account_id
, view_10.linked_acct_id
, view_10.prod_code
, view_10.region
, view_10.description
, view_10.unblended_rate
, view_10.storage_class
, view_10.servicecode
, view_10.operation
, view_10.usage_type
, view_10.charge_type
, view_10.year
, view_10.month
, view_10.period
, view_10.mth_order
, view_10.bucket_id
, view_10.usage
, view_10.bucket_cost
, view_10.line_item_usage_account_id
FROM
  join_month_10_S3_month_10_top_10_s3 view_10
UNION ALL
SELECT 
  view_11.bill_payer_account_id
, view_11.linked_acct_id
, view_11.prod_code
, view_11.region
, view_11.description
, view_11.unblended_rate
, view_11.storage_class
, view_11.servicecode
, view_11.operation
, view_11.usage_type
, view_11.charge_type
, view_11.year
, view_11.month
, view_11.period
, view_11.mth_order
, view_11.bucket_id
, view_11.usage
, view_11.bucket_cost
, view_11.line_item_usage_account_id
FROM
  join_month_11_S3_month_11_top_10_s3 view_11
UNION ALL
SELECT 
  view_12.bill_payer_account_id
, view_12.linked_acct_id
, view_12.prod_code
, view_12.region
, view_12.description
, view_12.unblended_rate
, view_12.storage_class
, view_12.servicecode
, view_12.operation
, view_12.usage_type
, view_12.charge_type
, view_12.year
, view_12.month
, view_12.period
, view_12.mth_order
, view_12.bucket_id
, view_12.usage
, view_12.bucket_cost
, view_12.line_item_usage_account_id
FROM
 join_month_12_S3_month_12_top_10_s3 view_12


UNION ALL
SELECT 
  view_13.bill_payer_account_id
, view_13.linked_acct_id
, view_13.prod_code
, view_13.region
, view_13.description
, view_13.unblended_rate
, view_13.storage_class
, view_13.servicecode
, view_13.operation
, view_13.usage_type
, view_13.charge_type
, view_13.year
, view_13.month
, view_13.period
, view_13.mth_order
, view_13.bucket_id
, view_13.usage
, view_13.bucket_cost
, view_13.line_item_usage_account_id
FROM
 join_month_13_S3_month_13_top_10_s3 view_13

-- end of create view