-- Create a S3 storage view for the join_month_07_S3_month_07_top_10_s3
CREATE OR REPLACE VIEW "join_month_07_S3_month_07_top_10_s3" AS 
SELECT DISTINCT
  view_07.bill_payer_account_id
, view_07.linked_acct_id
, view_07.prod_code
, view_07.region
, view_07.description
, view_07.unblended_rate
, view_07.storage_class
, view_07.servicecode
, view_07.operation
, view_07.usage_type
, view_07.charge_type
, view_07.year
, view_07.month
, view_07.period
, view_07.mth_order
, view_07.bucket_id
, view_07.usage
, view_07.bucket_cost
, view_07_top_10.line_item_usage_account_id
FROM
  (view_s3_month_07 view_07
INNER JOIN view_s3_month_07_top_10_accts view_07_top_10 ON (view_07.linked_acct_id = view_07_top_10.line_item_usage_account_id))

-- end of create view