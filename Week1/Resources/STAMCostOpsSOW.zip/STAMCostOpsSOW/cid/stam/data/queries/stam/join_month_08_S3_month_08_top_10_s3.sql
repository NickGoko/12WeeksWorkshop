-- Create a S3 storage view for the join_month_08_S3_month_08_top_10_s3
CREATE OR REPLACE VIEW "join_month_08_S3_month_08_top_10_s3" AS 
SELECT DISTINCT
  view_08.bill_payer_account_id
, view_08.linked_acct_id
, view_08.prod_code
, view_08.region
, view_08.description
, view_08.unblended_rate
, view_08.storage_class
, view_08.servicecode
, view_08.operation
, view_08.usage_type
, view_08.charge_type
, view_08.year
, view_08.month
, view_08.period
, view_08.mth_order
, view_08.bucket_id
, view_08.usage
, view_08.bucket_cost
, view_08_top_10.line_item_usage_account_id
FROM
  (view_s3_month_08 view_08
INNER JOIN view_s3_month_08_top_10_accts view_08_top_10 ON (view_08.linked_acct_id = view_08_top_10.line_item_usage_account_id))

-- end of create view