-- Create a S3 storage view for the join_month_11_s3_month_11_top_10_s3
CREATE OR REPLACE VIEW "join_month_11_s3_month_11_top_10_s3" AS 
SELECT DISTINCT
  view_11.bill_payer_account_id
, view_11.linked_acct_id
, view_11.prod_code
, view_11.region
, view_11.description
, view_11.unblended_rate
, view_11.storage_class
, view_11.servicecode
, view_11.operation
, view_11.usage_type
, view_11.charge_type
, view_11.year
, view_11.month
, view_11.period
, view_11.mth_order
, view_11.bucket_id
, view_11.usage
, view_11.bucket_cost
, view_11_top_10.line_item_usage_account_id
FROM
  (view_s3_month_11 view_11
INNER JOIN view_s3_month_11_top_10_accts view_11_top_10 ON (view_11.linked_acct_id = view_11_top_10.line_item_usage_account_id))

-- end of create view